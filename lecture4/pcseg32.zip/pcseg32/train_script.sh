#CUDA_VISIBLE_DEVICES=0,1 sh dist_train.sh 2 --cfg_file tools/cfgs/voxel/semantic_kitti/minkunet_mk34_cr16.yaml --pretrained_model logs/cfgs/voxel/semantic_kitti/minkunet_mk34_cr16/default/ckp/checkpoint_epoch_11.pth

#CUDA_VISIBLE_DEVICES=0,1 sh dist_train.sh 2 --cfg_file tools/cfgs/fusion/semantic_kitti/rpvnet_mk34_cr17_5.yaml --pretrained_model logs/fusion/semantic_kitti/rpvnet_mk34_cr17_5/default/ckp/checkpoint_epoch_6.pth


# 下面几个还没有确认batch-size,适合双30090-GPU的.

#CUDA_VISIBLE_DEVICES=0,1 sh dist_train.sh 2 --cfg_file tools/cfgs/fusion/semantic_kitti/spvcnn_mk18_cr5.yaml  # batch=20 递减

#CUDA_VISIBLE_DEVICES=0,1 sh dist_train.sh 2 --cfg_file tools/cfgs/fusion/semantic_kitti/spvcnn_mk18_cr10.yaml

#CUDA_VISIBLE_DEVICES=0,1 sh dist_train.sh 2 --cfg_file tools/cfgs/fusion/semantic_kitti/spvcnn_mk34_cr5.yaml

#CUDA_VISIBLE_DEVICES=0,1 sh dist_train.sh 2 --cfg_file tools/cfgs/fusion/semantic_kitti/spvcnn_mk34_cr16.yaml

CUDA_VISIBLE_DEVICES=0,1 sh dist_train.sh 2 --cfg_file tools/cfgs/voxel/semantic_kitti/cylinder_lp_cy480_cr5.yaml
