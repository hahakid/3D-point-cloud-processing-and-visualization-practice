import os
import numpy as np
from torch.utils import data
from .semantickitti_utils import LEARNING_MAP
from .LaserMix_semantickitti import lasermix_aug
from .PolarMix_semantickitti import polarmix
import random
import re
from .sequential.visualization import pose_init
from .sequential.visualization import project_t_1


# used for polarmix
instance_classes = [1, 2, 3, 4, 5, 6, 7, 8]  # 参考semantickitti.yaml 最后的learning_map
Omega = [np.random.random() * np.pi * 2 / 3, (np.random.random() + 1) * np.pi * 2 / 3]  # 2/3*pi* [n, n+1]

def absoluteFilePaths(directory):
    for dirpath, _, filenames in os.walk(directory):
        for f in filenames:
            yield os.path.abspath(os.path.join(dirpath, f))


class SemantickittiDataset(data.Dataset):
    def __init__(
        self,
        data_cfgs=None,
        training: bool = True,
        class_names: list = None,
        root_path: str = None,
        logger = None,
        if_scribble: bool = False,
    ):
        super().__init__()
        self.data_cfgs = data_cfgs
        self.root_path = root_path
        self.training = training
        self.logger = logger
        self.class_names = class_names
        self.raw_data_jk = []
        self.annotated_data_jk = []
        self.tta = data_cfgs.get('TTA', False)
        self.train_val = data_cfgs.get('TRAINVAL', False)
        self.augment = data_cfgs.AUGMENT  # only GlobalAugment_LP
        self.if_scribble = if_scribble

        # z:add----------------------------------------
        #self.pose_list = pose_init(self.root_path, train_set)
        self.augment_sequence = data_cfgs.get("AUGMENT_SEQUENCE", False)
        self.augment_method = data_cfgs.get("AUGMENT_METHOD", "both")
        self.shuffle = data_cfgs.get("SHUFFLE_IN_ALL_FRAME", True)
        self.is_add_two_frame = data_cfgs.get("ADD_TWO_FRAME", False)

        # ===============================================================

        if self.training and not self.train_val:
            self.split = 'train'
        else:
            if self.training and self.train_val:
                self.split = 'train_val'
            else:
                self.split = 'val'
        if self.tta:
            self.split = 'test'

        if self.split == 'train':
            #self.seqs = ['00', '01', '02', '03', '04', '05', '06', '07', '09', '10']  # all
            self.seqs = ["00"]      #local
            # self.seqs = ['00', '02']  # first 36
            # self.seqs = ['01', '03', '04', '05', '06', '07', '09', '10']  # last 37-72
        elif self.split == 'val':
            #self.seqs = ['08']  # ['08']
            self.seqs = ['01']
        elif self.split == 'train_val':
            self.seqs = ['00', '01', '02', '03', '04', '05', '06', '07', '09', '10', '08']
        elif self.split == 'test':  # 因爲沒有标签，实际没有准备.结果直接用 train,训练玩之后进行测试08, 所以在准备数据的时候,可以08为测试集
            self.seqs = ['11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21']
        else:
            raise Exception('split must be train/val/train_val/test.')
        # 读标签,
        self.annos = []     #/z:  用于存放所有的数据路径

        # z:add:=========================================
        self.poselist = pose_init(self.root_path, self.seqs)

        for seq in self.seqs:
            #print(seq)
            #print(os.path.join(os.path.abspath(self.root_path), 'velodyne', str(seq).zfill(2)))
            #print(os.path.exists(os.path.join(os.path.abspath(self.root_path), 'velodyne', str(seq).zfill(2))))
            self.annos += absoluteFilePaths('/'.join([self.root_path, 'velodyne', str(seq).zfill(2)]))  # 只到 velodyne/seq/
            #print(self.annos)
        self.annos.sort()
        self.annos_another = self.annos.copy()
        # 之前理解错误, another是用来进行数据增扩的,对它随机相当于乱序之后,
        random.shuffle(self.annos_another)  # 调序 debug for bug-4,
        print(f'The total sample is {len(self.annos)}')  # 19130 for kitti


        # z:add 在序列层面上随机,在序列内顺序===================================
        if self.shuffle == False:
            self.annos = self.sequence_level_random()

        # ================================================================

        self._sample_idx = np.arange(len(self.annos))   # z: idx是顺序的所有数据的索引
        # 基于配置获取 每个epoch的数据,
        self.samples_per_epoch = self.data_cfgs.get('SAMPLES_PER_EPOCH', -1)    # z: cfg  文件没有该项,所以直接就等于-1
        if self.samples_per_epoch == -1 or not self.training:  # 測試情況,在一个epoch使用所有的数据
            self.samples_per_epoch = len(self.annos)          # z: 随机输出的大小是整个大小,但是采用np.random.choice 会有重复

        if self.training:
            self.resample()  # random index
        else:
            self.sample_idx = self._sample_idx

        for i in range(0, len(self.annos)):
            raw_data = np.fromfile(self.annos[i], dtype=np.float32).reshape((-1, 4))
            self.raw_data_jk.append(raw_data)

            if self.if_scribble:  # ScribbleKITTI (weak label)
                annos = self.annos[i].replace('SemanticKITTI', 'ScribbleKITTI')
                annotated_data = np.fromfile(
                    annos.replace('velodyne', 'scribbles')[:-3] + 'label', dtype=np.uint32
                ).reshape((-1, 1))
            else:  # SemanticKITTI (full label)
                annotated_data = np.fromfile(  # z: 读取标签,用labels替换velodyne,到label文件夹下,读取index对应的label
                    self.annos[i].replace('velodyne', 'labels')[:-3] + 'label', dtype=np.uint32  # label index
                ).reshape((-1, 1))
            self.annotated_data_jk.append(annotated_data)
    # return data

    def __len__(self):
        return len(self.sample_idx)
    # uniform sample from @1 of size @2

    def resample(self):
        self.sample_idx = np.random.choice(self._sample_idx, self.samples_per_epoch)        # z:  对idx进行了随机,但是会有重复的文件在
        #  self.sample_idx = self._sample_idx  # no random for debug bug-4  # shutdown      # z:  但是貌似也没有用到sample_idx

    def setdata(self):
        for i in range(0,len(self.annos)):
            raw_data = np.fromfile(self.annos[i], dtype=np.float32).reshape((-1, 4))
            self.raw_data_jk.append(raw_data)

    # calculate the ring ID based on Vertical Angle--yaw
    def get_kitti_points_ringID(self, points):
        scan_x = points[:, 0]
        scan_y = points[:, 1]
        yaw = -np.arctan2(scan_y, -scan_x)   # theta = -arctan(-y/x)
        proj_x = 0.5 * (yaw / np.pi + 1.0)
        new_raw = np.nonzero((proj_x[1:] < 0.2) * (proj_x[:-1] > 0.8))[0] + 1
        proj_y = np.zeros_like(proj_x)
        proj_y[new_raw] = 1
        ringID = np.cumsum(proj_y)
        ringID = np.clip(ringID, 0, 63)  # ring 0-63 clip
        return ringID

    # return pc, label, path based on index
    def __getitem__(self, index):

        raw_data, annotated_data = self.get_one_frame(index)

        #z:add   两帧直接叠加,还没加坐标投影
        # =============================
        if self.training:
            if self.is_add_two_frame:
                raw_data, annotated_data = self.add_two_frame(index, raw_data, annotated_data)



        pc_data = {
            'xyzret': raw_data,  # n*5 x-y-z-intensity, ring#
            'labels': annotated_data.astype(np.uint8),
            'path': self.annos[index],
        }

        return pc_data

    @staticmethod
    def collate_batch(batch_list):
        raise NotImplementedError

    # z add
    def sequence_level_random(self):
        if self.split == 'train':
            annos_new = []
            seqs = self.seqs
            random.shuffle(seqs)
            for seq in seqs:
                temp_list = list(absoluteFilePaths('/'.join([self.root_path, 'velodyne', str(seq).zfill(2)])))
                temp_list.sort()
                annos_new += temp_list
        else:
                annos_new = self.annos
        return annos_new

    def get_one_frame(self, index):
        # 对point,直接读取文件
        # print(self.annos[index])  # print current lidar bin file
        raw_data = self.raw_data_jk[index]
        # raw_data = np.fromfile(self.annos[index], dtype=np.float32).reshape((-1, 4))  # 4*n point cloud
        # 对label
        if self.split == 'test':  # 测试模式,置为全0
            annotated_data = np.expand_dims(np.zeros_like(raw_data[:, 0], dtype=int), axis=1)
        else:
            # if self.if_scribble:  # ScribbleKITTI (weak label)
            #     annos = self.annos[index].replace('SemanticKITTI', 'ScribbleKITTI')
            #     annotated_data = np.fromfile(
            #         annos.replace('velodyne', 'scribbles')[:-3] + 'label', dtype=np.uint32
            #     ).reshape((-1, 1))
            # else:  # SemanticKITTI (full label)
            #     annotated_data = np.fromfile(  # z: 读取标签,用labels替换velodyne,到label文件夹下,读取index对应的label
            #         self.annos[index].replace('velodyne', 'labels')[:-3] + 'label', dtype=np.uint32  # label index
            #     ).reshape((-1, 1))
            annotated_data = self.annotated_data_jk[index]
            annotated_data = annotated_data & 0xFFFF  # semantic kitti label mask
            #  print(self.annos[index])  # kid added, for keyError: 326 problem, confirm data (fixed)
            annotated_data = np.vectorize(LEARNING_MAP.__getitem__)(annotated_data)  # 向量化操作
            # 把标签映射成0-19

        # z add-------------------------------------------------------------------
        if self.augment_method == "polarmix":
            prob = 0
        elif self.augment_method == "lasermix_aug":
            prob = 1
        elif self.augment_method == "both":
            prob = np.random.choice(2, 1)  # 50%-50% 选择两种模式
        # -------------------------------------------------------------------------

        # 使用lasermix_aug() 进行点云样本曾扩, voxel 和fusion 使用, range 因为是range map, 推荐是NoAugment
        # 这个函数里面没有 也没有 GlobalAugment模式
        # 50% 选择 lasermix_aug, 50% 选择 polarmix

        if self.augment == 'GlobalAugment_LP':  # only implemented, no GlobalAugment
            if self.augment_sequence == 0:
                if self.split == 'train' and prob == 1:  # 仅在训练train 模式 进行点云样本曾扩
                    raw_data1 = np.fromfile(self.annos_another[index], dtype=np.float32).reshape((-1, 4))

                    if self.if_scribble:  # ScribbleKITTI (weak label)
                        annos1 = self.annos_another[index].replace('SemanticKITTI', 'ScribbleKITTI')
                        annotated_data1 = np.fromfile(
                            annos1.replace('velodyne', 'scribbles')[:-3] + 'label', dtype=np.uint32
                        ).reshape((-1, 1))
                    else:  # SemanticKITTI (full labels)
                        annotated_data1 = np.fromfile(
                            self.annos_another[index].replace('velodyne', 'labels')[:-3] + 'label', dtype=np.uint32
                        ).reshape((-1, 1))

                    annotated_data1 = annotated_data1 & 0xFFFF
                    annotated_data1 = np.vectorize(LEARNING_MAP.__getitem__)(annotated_data1)
                    assert len(annotated_data1) == len(raw_data1)
                    raw_data, annotated_data = lasermix_aug(  # 输入两帧不同point 和 label
                        raw_data,
                        annotated_data,
                        raw_data1,
                        annotated_data1,
                    )

                elif self.split == 'train' and prob == 0:
                    raw_data1 = np.fromfile(self.annos_another[index], dtype=np.float32).reshape(
                        (-1, 4))  # n*4  # z:another是调过顺序之后的路径列表

                    if self.if_scribble:  # ScribbleKITTI (weak label)
                        annos1 = self.annos_another[index].replace('SemanticKITTI', 'ScribbleKITTI')
                        annotated_data1 = np.fromfile(
                            annos1.replace('velodyne', 'scribbles')[:-3] + 'label', dtype=np.uint32
                        ).reshape((-1, 1))
                    else:  # SemanticKITTI (full label)
                        annotated_data1 = np.fromfile(  # z:读进来其他bin文件的一个标签
                            self.annos_another[index].replace('velodyne', 'labels')[:-3] + 'label', dtype=np.uint32
                        ).reshape((-1, 1))

                    annotated_data1 = annotated_data1 & 0xFFFF
                    annotated_data1 = np.vectorize(LEARNING_MAP.__getitem__)(annotated_data1)
                    assert len(annotated_data1) == len(raw_data1)
                    ################ prepare ######################
                    alpha = (np.random.random() - 1) * np.pi
                    beta = alpha + np.pi
                    annotated_data1 = annotated_data1.reshape(-1)
                    annotated_data = annotated_data.reshape(-1)
                    #############################################
                    raw_data, annotated_data = polarmix(  # polarmix 增强
                        raw_data, annotated_data, raw_data1, annotated_data1,
                        alpha=alpha, beta=beta,
                        instance_classes=instance_classes, Omega=Omega
                    )
                    annotated_data = annotated_data.reshape(-1, 1)

            # new=============================================================================================================
            elif self.augment_sequence == 1:
                if index == 0:  # 第0帧随机增强
                    index1 = random.randint(0, len(self.annos) - 1)
                elif index != 0:
                    index1 = index - 1

                if self.split == 'train' and prob == 1:  # 仅在训练train 模式 进行点云样本曾扩
                    raw_data1 = np.fromfile(self.annos[index1], dtype=np.float32).reshape((-1, 4))

                    if self.if_scribble:  # ScribbleKITTI (weak label)
                        annos1 = self.annos[index1].replace('SemanticKITTI', 'ScribbleKITTI')
                        annotated_data1 = np.fromfile(
                            annos1.replace('velodyne', 'scribbles')[:-3] + 'label', dtype=np.uint32
                        ).reshape((-1, 1))
                    else:  # SemanticKITTI (full labels)
                        annotated_data1 = np.fromfile(
                            self.annos[index1].replace('velodyne', 'labels')[:-3] + 'label', dtype=np.uint32
                        ).reshape((-1, 1))

                    annotated_data1 = annotated_data1 & 0xFFFF
                    annotated_data1 = np.vectorize(LEARNING_MAP.__getitem__)(annotated_data1)
                    assert len(annotated_data1) == len(raw_data1)
                    raw_data, annotated_data = lasermix_aug(  # 输入两帧不同point 和 label
                        raw_data,
                        annotated_data,
                        raw_data1,
                        annotated_data1,
                    )

                elif self.split == 'train' and prob == 0:
                    raw_data1 = np.fromfile(self.annos[index1], dtype=np.float32).reshape(
                        (-1, 4))  # n*4  # z:another是调过顺序之后的路径列表

                    if self.if_scribble:  # ScribbleKITTI (weak label)
                        annos1 = self.annos[index1].replace('SemanticKITTI', 'ScribbleKITTI')
                        annotated_data1 = np.fromfile(
                            annos1.replace('velodyne', 'scribbles')[:-3] + 'label', dtype=np.uint32
                        ).reshape((-1, 1))
                    else:  # SemanticKITTI (full label)
                        annotated_data1 = np.fromfile(  # z:读进来其他bin文件的一个标签
                            self.annos[index1].replace('velodyne', 'labels')[:-3] + 'label', dtype=np.uint32
                        ).reshape((-1, 1))

                    annotated_data1 = annotated_data1 & 0xFFFF
                    annotated_data1 = np.vectorize(LEARNING_MAP.__getitem__)(annotated_data1)
                    assert len(annotated_data1) == len(raw_data1)
                    ################ prepare ######################
                    alpha = (np.random.random() - 1) * np.pi
                    beta = alpha + np.pi
                    annotated_data1 = annotated_data1.reshape(-1)
                    annotated_data = annotated_data.reshape(-1)
                    #############################################
                    raw_data, annotated_data = polarmix(  # polarmix 增强
                        raw_data, annotated_data, raw_data1, annotated_data1,
                        alpha=alpha, beta=beta,
                        instance_classes=instance_classes, Omega=Omega
                    )
                    annotated_data = annotated_data.reshape(-1, 1)
            # new=============================================================================================================

        ringID = self.get_kitti_points_ringID(raw_data).reshape((-1, 1))
        raw_data = np.concatenate([raw_data, ringID.reshape(-1, 1)], axis=1).astype(np.float32)

        return raw_data, annotated_data

    def add_two_frame(self, index, raw_data, annotated_data):
        present_frame_file = self.annos[index][-10: -4]      #  [-10: -4]

        if present_frame_file != '000000':
            raw_data1, annotated_data1 = self.get_one_frame(index-1)

            #project_t_1(index, raw_data, raw_data1, self.pose_list)
            raw_data, annotated_data = project_t_1(self.root_path, index, raw_data, annotated_data, raw_data1, annotated_data1, self.poselist)


            # raw_data = np.concatenate((raw_data, raw_data1), axis=0)

            # annotated_data = np.concatenate((annotated_data, annotated_data1), axis=0)

        return raw_data, annotated_data


