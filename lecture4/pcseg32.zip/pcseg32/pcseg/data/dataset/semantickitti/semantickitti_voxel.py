'''
This file is modified from https://github.com/mit-han-lab/spvnas
'''


import numpy as np
import torch
from torch.utils import data
from .semantickitti import SemantickittiDataset
from torchsparse import SparseTensor
from torchsparse.utils.collate import sparse_collate_fn
from torchsparse.utils.quantize import sparse_quantize
from itertools import accumulate
from tools.utils.common.seg_utils import aug_points

def cart2polar(input_xyz):
    rho = np.sqrt(input_xyz[:, 0] ** 2 + input_xyz[:, 1] ** 2)  # 半径 r=sqrt(x^2+y^2)
    phi = np.arctan2(input_xyz[:, 1], input_xyz[:, 0])  # 角度 =arctan(y/x)
    return np.stack((rho, phi, input_xyz[:, 2]), axis=1)  # [ _, _,z]


def voxelize_with_label(point_coords, point_labels, num_classes):
    # 体素坐标, 正向映射p2v, 反向映射v2p
    voxel_coords, inds, inverse_map = sparse_quantize(
        point_coords,
        return_index=True,              #zadd: inds 正着过去,从原来的点云,映射到,去重的点云,inverse,就是反着回来,从少的点云,映射回多的点云
        return_inverse=True,
    )
    # 体素cls的计数器: 基于体素坐标, 生成空的数组[# of voxel * cls]
    voxel_label_counter = np.zeros([voxel_coords.shape[0], num_classes])
    # 基于p2v映射, 统计每个体素内的标签, 最后用于max voting
    for ind in range(len(inverse_map)):
        if point_labels[ind] != 67:  # 100%触发, why 67?
            voxel_label_counter[inverse_map[ind]][point_labels[ind]] += 1  # param1=row, voxel；param2=col, cls #, 计数器+1
    voxel_labels = np.argmax(voxel_label_counter, axis=1)  # max voting
    # 返回 体素坐标, 体素标签, p2v mapping, v2p mapping
    return voxel_coords, voxel_labels, inds, inverse_map

class SemkittiVoxelDataset(data.Dataset):
    def __init__(
        self,
        data_cfgs=None,
        training=True,
        root_path=None,
        logger=None
    ):
        super().__init__()
        self.data_cfgs = data_cfgs
        self.training = training
        self.class_names = [
            "unlabeled",  # ignored
            "car", "bicycle", "motorcycle", "truck", "other-vehicle", "person", "bicyclist", "motorcyclist",  # dynamic
            "road", "parking", "sidewalk", "other-ground", "building", "fence", "vegetation", "trunk", "terrain", "pole", "traffic-sign"  # static
        ]
        self.root_path = root_path if root_path is not None else self.data_cfgs.DATA_PATH
        self.logger = logger

        self.point_cloud_dataset = SemantickittiDataset(
            data_cfgs=data_cfgs,
            training=training,
            class_names=self.class_names,
            root_path=self.root_path,
            logger=logger,
            if_scribble=True if self.data_cfgs.DATASET == 'scribblekitti' else False,
        )
        #  differ-1: voxel related parameters.
        self.voxel_size = data_cfgs.VOXEL_SIZE
        self.num_points = data_cfgs.NUM_POINTS  # set to 1,000,000, vlp64= 1,800*64=115,200
        # data augmentation
        self.if_flip = data_cfgs.get('FLIP_AUG', True)
        self.if_scale = data_cfgs.get('SCALE_AUG', True)
        self.scale_axis = data_cfgs.get('SCALE_AUG_AXIS', 'xyz')
        self.scale_range = data_cfgs.get('SCALE_AUG_RANGE', [0.9, 1.1])  # 这个没看见有相关配置
        self.if_jitter = data_cfgs.get('TRANSFORM_AUG', True)
        self.if_rotate = data_cfgs.get('ROTATE_AUG', True)
        # any function related to tta, first ignored
        self.if_tta = self.data_cfgs.get('TTA', False)

        # zadd:--------------------------------------------------------------------------------------
        self.if_cylinder = self.data_cfgs.get("CYLINDER_MINK", False)
        self.cylinder_space_max = np.array(data_cfgs.get("CYLINDER_SPACE_MAX", 0))  # [ 50, 180, 2 ]
        self.cylinder_space_min = np.array(data_cfgs.get("CYLINDER_SPACE_MIN", 0))  # [ 0, -180, -4 ]
        self.grid_size = np.array(data_cfgs.get("CYLINDER_GRID_SIZE", 0))  # none

        print()


    # same
    def __len__(self):
        'Denotes the total number of samples'
        return len(self.point_cloud_dataset)

    def __getitem__(self, index):
        if self.if_tta:  # any function related to tta, first ignored
            data_total = []
            voting = 10  
            for idx in range(voting):
                data_single = self.get_single_sample(index, idx)
                data_total.append(data_single)
            return data_total
        else:
            if self.if_cylinder == False:
                data = self.get_single_sample(index)  # used
            else:
                data = self.get_cylinder_single_sample(index)

            return data

    def get_single_sample(self, index, voting_idx=0):
        'Generates one sample of data'
        pc_data = self.point_cloud_dataset[index]
        point_label = pc_data['labels'].reshape(-1)
        point = pc_data['xyzret'][:, :4].astype(np.float32)  # 这里只取了 xyzr, ring# 一方面是同质化太严重,另外是xyz的非线性映射,意义大不大不确定

        num_points_current_frame = point.shape[0]
        ret = {}
        if self.training:
            # print("get_single_sample_Training", self.scale_range)  # only to show if this function is used
            # 训练前,对point cloud进行 point级别的随机化.
            point[:, 0:3] = aug_points(  # x-y-z, point-level-randomization_flag
                xyz=point[:, :3],  # 进一步,只取了 0-1-2, 反射率也丢弃了
                if_flip=self.if_flip,
                if_scale=self.if_scale,
                scale_axis=self.scale_axis,
                scale_range=self.scale_range,  # 与scale_axis连用
                if_jitter=self.if_jitter,
                if_rotate=self.if_rotate,
                if_tta=self.if_tta,
            )
        # any function related to tta, first ignored
        elif self.if_tta:
            self.if_flip = False
            self.if_scale = True
            self.scale_aug_range = [0.95, 1.05]
            self.if_jitter = False
            self.if_rotate = True
            point[:, 0:3] = aug_points(
                xyz=point[:, :3],
                if_flip=self.if_flip,
                if_scale=self.if_scale,
                scale_axis=self.scale_axis,
                scale_range=self.scale_range,
                if_jitter=self.if_jitter,
                if_rotate=self.if_rotate,
                if_tta=True,
                num_vote=voting_idx,
        )

        # voxel-based feature generation
        pc_ = np.round(point[:, :3] / self.voxel_size).astype(np.int32)  # 0.05
        pc_ -= pc_.min(0, keepdims=1)  # 帧内, 局部/当前帧坐标的  去中心化: 都减去最小值(雷达扫描一定最小值为负), 向坐标轴正方向平移
        feat_ = point  # 初始特征就是: 原始坐标+反射率, 与这里的 pc_ 区分
        # torch sparse 内部函数  N-to-1 映射, 拿hashmap
        _, inds, inverse_map = sparse_quantize(  # return coords, indices, inverse_indices
            pc_,
            return_index=True,
            return_inverse=True,
        )
        if self.training and len(inds) > self.num_points:  # NOTE: num_points must always bigger than self.num_points
            raise RuntimeError('droping point')  # 体素化之后, 体素规模大于原始点云, 还有这种情况?
            #  基于体素化进行一次随机筛选, 每个体素保留 一个点的信息.
            inds = np.random.choice(inds, self.num_points, replace=False)
        # voxel based feature, 基于映射关系, 更新体素坐标
        # 带inds,都是基于 体素映射
        pc = pc_[inds]  # 体素化坐标
        feat = feat_[inds]  # 原始特征 n*4
        labels = point_label[inds]  # 体素标签 n*1
        # to sparsetensor
        lidar = SparseTensor(feat, pc)  # @feature @coords
        labels = SparseTensor(labels, pc)
        labels_ = SparseTensor(point_label, pc_)
        inverse_map = SparseTensor(inverse_map, pc_)
        ret = {  # dict for new data structure
            'name': pc_data['path'],
            'lidar': lidar,
            'targets': labels,
            'targets_mapped': labels_,
            'inverse_map': inverse_map,
            'num_points': np.array([num_points_current_frame]),  # for multi frames
        }

        return ret

    def get_cylinder_single_sample(self, index, voting_idx=0):
        'Generates one sample of data'
        pc_data = self.point_cloud_dataset[index]
        point_label = pc_data['labels'].reshape(-1)
        point = pc_data['xyzret'][:, :4]  # 0-3=xyzr, ring# 同样没参与计算 pc_data['xyzret'][:, :5]

        num_points_current_frame = point.shape[0]

        ret = {}
        # training phase
        if self.training:
            # print("get_single_sample_Training", self.scale_range)
            point[:, 0:3] = aug_points(  # x-y-z, point-level-randomization_flag      #进行了随机旋转,反转,抖动,缩放
                xyz=point[:, :3],
                if_flip=self.if_flip,
                if_scale=self.if_scale,
                scale_axis=self.scale_axis,
                scale_range=self.scale_range,
                if_jitter=self.if_jitter,
                if_rotate=self.if_rotate,
                if_tta=self.if_tta,
            )
        # tta=False, unused
        elif self.if_tta:
            self.if_flip = False
            self.if_scale = True
            self.scale_aug_range = self.scale_range  # [0.95, 1.05]  # modified to read from yaml
            self.if_jitter = False
            self.if_rotate = True
            point[:, 0:3] = aug_points(
                xyz=point[:, :3],
                if_flip=self.if_flip,
                if_scale=self.if_scale,
                scale_axis=self.scale_axis,
                scale_range=self.scale_range,
                if_jitter=self.if_jitter,
                if_rotate=self.if_rotate,
                if_tta=True,
                num_vote=voting_idx,  # 只在tta模式下用到, 默认无用吧先
            )
        # cylinder-based feature generation
        '''
        1. coordinate conversion
        2. crop based on boundary, 获取间隔划分
        3. clip裁剪, 间隔之外的点将被裁剪到边缘
        '''
        xyz_pol = cart2polar(point[:, :3])  # 极坐标, 计算后第一维不存在负数, sqrt(x^2+y^2)
        xyz_pol[:, 1] = xyz_pol[:, 1] / np.pi * 180.  # 第二维 radian-to-degree
        max_bound = self.cylinder_space_max  # crop boundary-max read from yaml
        min_bound = self.cylinder_space_min  # crop boundary-min read from yaml

        crop_range = max_bound - min_bound
        cur_grid_size = self.grid_size  # [ 480, 360, 32 ]
        intervals = crop_range / (cur_grid_size - 1)  # 范围/分辨率=间隔

        # 给定一个间隔，该间隔之外的值将被剪裁到间隔边缘。主要产生误分的点处于r>50的情况,全部集中到了50
        # 去中心化, 然后坐标系平移 -min_bound, 主要是将 \phi 和 z 变为正值
        # 最后 / intervals, 除以间隔,将index变成坐标, 0-50  变为  0-479, 0-6 变为 0 - 31
        # 转换后的point_coord 实际上已经是 voxel的编码了
        # Statistical range of r, z only
        '''
        rrr = xyz_pol[:, 0]  # map to [0:50]
        zzz = xyz_pol[:, 2]  # map to [-4:2]
        step1 = np.clip(xyz_pol, min_bound, max_bound)
        step2 = step1 - min_bound
        step3 = np.floor(step2) / intervals
        '''
        point_coord = (np.floor((np.clip(xyz_pol, min_bound, max_bound) - min_bound) / intervals)).astype(
            np.int32)  # z:add: 通过最大值最小值进行裁剪, 并将z轴向上平移4,都变成正值
        # n-to-1 mapping                                                                                                                                角也变成0-360
        # inds: 体素对应的点索引
        # inverse_map: 点对应的体素索引
        voxel_coord, voxel_label, inds, inverse_map = voxelize_with_label(  # point-to-voxel
            point_coord, point_label, len(self.class_names))
        # 针对point_coord的逆运算, center = (index+0.5) * intervals, 0-479 变为 1-480 变为 0 - 50, 并对\phi和z 平移回去
        # 唯一
        voxel_centers = (voxel_coord.astype(np.float32) + 0.5) * intervals + min_bound  # 特征要加回平移的min_bound


            # 特征包括 voxel_centers, 极坐标编码[inds-体素索引部分坐标], 迪卡尔下的 point[x,y], point[r], 只有z是没参与计算的,其余都是映射
        # voxel_feature = np.concatenate([voxel_centers, xyz_pol[inds], point[inds][:, :2], point[inds][:, 3:]],
        #                                   axis=1)

        # 针对point_coord的逆运算, center = (index+0.5) * intervals, 0-479 变为 1-480 变为 0 - 50, 并对\phi和z 平移回去
        # 不唯一
        point_voxel_centers = (point_coord.astype(np.float32) + 0.5) * intervals + min_bound  # 特征要加回平移min_bound


            # 与voxel_feature 相比, 不需要n-to-1映射, 直接全部点参与计算, 坐标同样包含极坐标+迪卡尔
        point_feature = np.concatenate([point_voxel_centers, xyz_pol, point[:, :2], point[:, 3:]], axis=1)
         # z:原点数量,体素3   原点数量极坐标没变换,角度有负值3   原点xy 2   ret 1


        # zadd: --------------------------------------------------------------------------------------------------------
        pc_ = point_coord
        pc = voxel_coord
        feat = np.concatenate([voxel_centers, point[inds][:, 3:]], axis=1).astype(np.float32)
        labels = voxel_label.astype(np.uint8)

        lidar = SparseTensor(feat, pc)  # @feature @coords
        labels = SparseTensor(labels, pc)
        labels_ = SparseTensor(point_label, pc_)
        inverse_map = SparseTensor(inverse_map, pc_)

        ret = {  # dict for new data structure
            'name': pc_data['path'],
            'lidar': lidar,
            'targets': labels,
            'targets_mapped': labels_,
            'inverse_map': inverse_map,
            'num_points': np.array([num_points_current_frame]),  # for multi frames
        }


        # 注意,这里并没有对[坐标,特征] 进行SparseTenser的计算转化


        return ret

    @staticmethod
    def collate_batch(inputs):
        offset = [sample['lidar'].C.shape[0] for sample in inputs]  # for point transformer
        offsets = {}
        ret = sparse_collate_fn(inputs)
        ret.update(dict(
            offset=torch.tensor(list(accumulate(offset))).int()
        ))
        return ret
    # ignored
    @staticmethod
    def collate_batch_tta(inputs):
        inputs = inputs[0]
        offset = [sample['lidar'].C.shape[0] for sample in inputs]  # for point transformer
        offsets = {}

        ret = sparse_collate_fn(inputs)
        ret.update(dict(
            offset=torch.tensor(list(accumulate(offset))).int()
        ))
        return ret

