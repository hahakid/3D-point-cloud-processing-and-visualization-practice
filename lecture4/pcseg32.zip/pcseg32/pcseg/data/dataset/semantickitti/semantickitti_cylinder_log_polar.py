'''
This file is modified from https://github.com/xinge008/Cylinder3D
https://github.com/xinge008/Cylinder3D/blob/master/dataloader/dataset_semantickitti.py

在此基础上,对r进行log化处理的划分,精确到小数点后2位即可? cm厘米级,
采用此操作可以进一步压缩r,经向轴的由近及远的划分? 也就是压缩了 480 的分辨率,
同时考虑增加对z轴的分辨率提升--log化

'''


from collections import defaultdict
from itertools import accumulate
import numpy as np
import torch
from torch.utils import data
from torchsparse.utils.quantize import sparse_quantize

from .semantickitti import SemantickittiDataset

from tools.utils.common.seg_utils import aug_points

base = 1.09  # base =2 or np.e is too large  # change the base for log
base1 = 1.09

def z_trans_log(input_xyz, base, z_min):
    '''
        trans: z_new = z_old + 指数e的底 - min (min为负值)
        log: z_log = log_{base}^{z_new} = log(z_new) / log(base)
        没有和下面进行集成, 想先进行独立测试, 看看效果
    '''
    z = input_xyz[:, 2] + base - z_min
    z = np.log(z) / np.log(base)
    return np.stack((input_xyz[:, 0], input_xyz[:, 1], z), axis=1)


# transformation between Cartesian coordinates and polar coordinates
def cart2polar(input_xyz):
    rho = np.sqrt(input_xyz[:, 0] ** 2 + input_xyz[:, 1] ** 2)  # 半径 r=sqrt(x^2+y^2)
    phi = np.arctan2(input_xyz[:, 1], input_xyz[:, 0])  # 角度 =arctan(y/x)
    return np.stack((rho, phi, input_xyz[:, 2]), axis=1)  # [ _, _,z]


# corrected, but not called
def polar2cat(input_xyz_polar):
    # print(input_xyz_polar.shape)
    x = input_xyz_polar[0] * np.cos(input_xyz_polar[1])  # x = r * cos(\phi)
    y = input_xyz_polar[0] * np.sin(input_xyz_polar[1])  # y = r * sin(\phi)
    # x = input_xyz_polar[:, 0] * np.cos(input_xyz_polar[:, 1])  # x = r * cos(\phi)
    # y = input_xyz_polar[:, 0] * np.sin(input_xyz_polar[:, 1])  # y = r * sin(\phi)
    return np.stack((x, y, input_xyz_polar[2]), axis=0)

def cart2logpolar(input_xyz, base):
    '''
        <del>先用自然指数e做底</del> base can be assigned, and negative values are avoided
        r=ln(sqrt(x^2+y^2))
        phi = atan2(y,x)
        more common:
        log_{base}^{x} = log(x) / log(base)
    '''
    rho = np.log(np.sqrt(input_xyz[:, 0] ** 2 + input_xyz[:, 1] ** 2)) / np.log(base)  # base=e
    phi = np.arctan2(input_xyz[:, 1], input_xyz[:, 0])
    return np.stack((rho, phi, input_xyz[:, 2]), axis=1)


# un-used in current project
def logpolar2cat(input_xyz_logpolar, base):
    '''
        <del>r = e^p</del>  # more common r = base^p
        x = r * cos(phi)
        y = r * sin(phi)
    '''

    # x = np.exp(input_xyz_logpolar[:, 0]) * np.cos(input_xyz_logpolar[:, 1])
    # y = np.exp(input_xyz_logpolar[:, 0]) * np.sin(input_xyz_logpolar[:, 1])
    r = np.power(base, input_xyz_logpolar[:, 0])
    x = r * np.cos(input_xyz_logpolar[:, 1])
    y = r * np.sin(input_xyz_logpolar[:, 1])
    return np.stack((x, y, input_xyz_logpolar[:, 2]), axis=1)


def voxelize_with_label(point_coords, point_labels, num_classes):
    # 体素坐标, 正向映射p2v, 反向映射v2p
    voxel_coords, inds, inverse_map = sparse_quantize(
        point_coords,
        return_index=True,
        return_inverse=True,
    )
    # 体素cls的计数器: 基于体素坐标, 生成空的数组[# of voxel * cls]
    voxel_label_counter = np.zeros([voxel_coords.shape[0], num_classes])
    # 基于p2v映射, 统计每个体素内的标签, 最后用于max voting
    for ind in range(len(inverse_map)):
        if point_labels[ind] != 67:  # 100%触发, why 67?
            voxel_label_counter[inverse_map[ind]][point_labels[ind]] += 1  # param1=row, voxel；param2=col, cls #, 计数器+1
    voxel_labels = np.argmax(voxel_label_counter, axis=1)  # max voting
    # 返回 体素坐标, 体素标签, p2v mapping, v2p mapping
    return voxel_coords, voxel_labels, inds, inverse_map


class SemkittiCylinderLPDataset(data.Dataset):
    def __init__(
        self,
        data_cfgs = None,
        training = True,
        root_path = None,
        logger = None
    ):
        super().__init__()
        self.data_cfgs = data_cfgs
        self.training = training
        self.class_names = [
            "unlabeled",  # ignored
            "car", "bicycle", "motorcycle", "truck", "other-vehicle", "person", "bicyclist", "motorcyclist",  # dynamic
            "road", "parking", "sidewalk", "other-ground", "building", "fence", "vegetation", "trunk", "terrain", "pole", "traffic-sign"  # static
        ]
        self.root_path = root_path if root_path is not None else self.data_cfgs.DATA_PATH
        self.logger = logger

        self.point_cloud_dataset = SemantickittiDataset(
            data_cfgs=data_cfgs,
            training=training,
            class_names=self.class_names,
            root_path=self.root_path,
            logger=logger
        )
        #  differ-1: cylinder related parameters.
        self.cylinder_space_max = np.array(data_cfgs.CYLINDER_SPACE_MAX)  # [ 50, 180, 2 ]
        self.cylinder_space_min = np.array(data_cfgs.CYLINDER_SPACE_MIN)  # [ 0, -180, -4 ]
        self.grid_size = np.array(data_cfgs.CYLINDER_GRID_SIZE)  # none

        #  same again, for yaml DATA
        self.if_flip = data_cfgs.get('FLIP_AUG', True)
        self.if_scale = data_cfgs.get('SCALE_AUG', True)
        self.scale_axis = data_cfgs.get('SCALE_AUG_AXIS', 'xyz')
        self.scale_range = data_cfgs.get('SCALE_AUG_RANGE', [0.95, 1.05])  # [0.9, 1.1] for fusion and voxel
        self.if_jitter = data_cfgs.get('TRANSFORM_AUG', True)  # 默认开
        self.if_rotate = data_cfgs.get('ROTATE_AUG', True)  # 默认开
        
        self.if_tta = self.data_cfgs.get('TTA', False)
        # added flag for log / log_polar, z_axis
        self.log_polar = self.data_cfgs.get('LOG_POLAR', False)  # 默认polar, True=log_polar
        self.change_z = self.data_cfgs.get('Change_Z', False)  # 默认迪卡尔, True=log

        # added for point_feature dim  # added for point_feature dim  # data cfg 没有包含 model的元素,除非在yaml data域再加一个
        self.dim = self.data_cfgs.get('IN_FEATURE_DIM', 9)

        # same, sample len
    def __len__(self):
        'Denotes the total number of samples'
        return len(self.point_cloud_dataset)

    # same as voxel, will call get_single_sample with point-level operation
    # 实际承担从数据集采样
    def __getitem__(self, index):
        if self.if_tta:
            data_total = []
            voting = 10  
            for idx in range(voting):
                data_single = self.get_single_sample(index, idx)
                data_total.append(data_single)
            return data_total
        else:  # from here
            data = self.get_single_sample(index)  # called
            return data

    # 基于index 获取对应数据, 并进行point-level的数据增强
    def get_single_sample(self, index, voting_idx=0):
        'Generates one sample of data'
        pc_data = self.point_cloud_dataset[index]
        point_label = pc_data['labels'].reshape(-1)
        point = pc_data['xyzret'][:, :4]  # 0-3=xyzr, ring# 同样没参与计算 pc_data['xyzret'][:, :5]

        # add pre-process of filtering points with in radius < base, i.e., x^2+y^2 < base^2, forbid log < 0
        filtered = np.where(point[:, 0] ** 2 + point[:, 1] ** 2 >= base ** 2)
        point = point[filtered]
        point_label = point_label[filtered]

        num_points_current_frame = point.shape[0]

        ret = {}
        # training phase
        if self.training:
            # print("get_single_sample_Training", self.scale_range)
            point[:, 0:3] = aug_points(  # x-y-z, point-level-randomization_flag
                xyz=point[:, :3],
                if_flip=self.if_flip,
                if_scale=self.if_scale,
                scale_axis=self.scale_axis,
                scale_range=self.scale_range,
                if_jitter=self.if_jitter,
                if_rotate=self.if_rotate,
                if_tta=self.if_tta,
            )
        # tta=False, unused
        elif self.if_tta:
            self.if_flip = False
            self.if_scale = True
            self.scale_aug_range = self.scale_range  # [0.95, 1.05]  # modified to read from yaml
            self.if_jitter = False
            self.if_rotate = True
            point[:, 0:3] = aug_points(
                xyz=point[:, :3],
                if_flip=self.if_flip,
                if_scale=self.if_scale,
                scale_axis=self.scale_axis,
                scale_range=self.scale_range,
                if_jitter=self.if_jitter,
                if_rotate=self.if_rotate,
                if_tta=True,
                num_vote=voting_idx,
            )
        # cylinder-based feature generation
        '''
        1. coordinate conversion
        2. crop based on boundary, 获取间隔划分
        3. clip裁剪, 间隔之外的点将被裁剪到边缘
        '''

        max_bound = self.cylinder_space_max  # crop boundary-max read from yaml
        min_bound = self.cylinder_space_min  # crop boundary-min read from yaml

        if self.log_polar:
            # log-polar
            xyz_logpol = cart2logpolar(point[:, :3], base)  # 极坐标, 计算后第一维不存在负数, sqrt(x^2+y^2)
        else:
            # log
            xyz_logpol = cart2polar(point[:, :3])  # 极坐标, 计算后第一维不存在负数, sqrt(x^2+y^2)

        xyz_logpol[:, 1] = xyz_logpol[:, 1] / np.pi * 180.  # 第二维 radian-to-degree

        # 给定一个间隔，该间隔之外的值将被剪裁到间隔边缘。主要产生误分的点处于r>50的情况,全部集中到了50
        # 去中心化, 然后坐标系平移 -min_bound, 主要是将 \phi 和 z 变为正值
        # 最后 / intervals, 除以间隔,将index变成坐标, 0-50  变为  0-479, 0-6 变为 0 - 31
        # 转换后的point_coord 实际上已经是 voxel的编码了
        # Statistical range of r, z only
        '''
        rrr = xyz_pol[:, 0]  # map to [0:50]
        zzz = xyz_pol[:, 2]  # map to [-4:2]
        step1 = np.clip(xyz_pol, min_bound, max_bound)
        step2 = step1 - min_bound
        step3 = np.floor(step2) / intervals
        '''
        # point_coord = (np.floor((np.clip(xyz_logpol, min_bound, max_bound) - min_bound) / intervals)).astype(np.int32)

        # 该操作必须放到 floor+clip之后, 从而保证最小值=base
        #if self.change_z:
            # 对z轴的处理, 平移会影响后续的 np.clip, 函数的输入与初始yaml配置有关
            # z_final = xyz_logpol[:, 2]


        # 使用clip主要是为了后续, point_coord与point_label依然对应
        xyz_logpol = np.clip(xyz_logpol, min_bound, max_bound)  # step-1, z轴没转换前用之前的范围
        #zzz = xyz_logpol[:, 2]
        if self.change_z:
            xyz_logpol = z_trans_log(xyz_logpol, base1, self.cylinder_space_min[2])  # change Z-axis
            #zzz = xyz_logpol[:, 2]
            max_bound[2] = np.log(max_bound[2] + base - self.cylinder_space_min[2]) / np.log(base)
            min_bound[2] = np.log(min_bound[2] + base - self.cylinder_space_min[2]) / np.log(base)

        crop_range = max_bound - min_bound
        cur_grid_size = self.grid_size  # [ 480, 360, 32 ]
        intervals = crop_range / (cur_grid_size - 1)  # 范围/分辨率=间隔
        point_coord = (np.floor((xyz_logpol - min_bound) / intervals)).astype(np.int32)  # step-2
        #zzz = point_coord[:, 2]
        # n-to-1 mapping
        # inds: 体素对应的点索引
        # inverse_map: 点对应的体素索引
        voxel_coord, voxel_label, inds, inverse_map = voxelize_with_label(  # point-to-voxel
            point_coord, point_label, len(self.class_names))
        # 针对point_coord的逆运算, center = (index+0.5) * intervals, 0-479 变为 1-480 变为 0 - 50, 并对\phi和z 平移回去
        # 唯一
        voxel_centers = (voxel_coord.astype(np.float32) + 0.5) * intervals + min_bound  # 特征要加回平移的min_bound
        if self.dim == 9:
            # 还有一种9没实现, 需要对比, point[:, :3] 的情况
            # 特征包括 voxel_centers, 极坐标编码[inds-体素索引部分坐标], 迪卡尔下的 point[x,y], point[r], 只有z是没参与计算的,其余都是映射
            voxel_feature = np.concatenate([voxel_centers, xyz_logpol[inds], point[inds][:, :2], point[inds][:, 3:]], axis=1)
        else:
            voxel_feature = np.concatenate([voxel_centers, xyz_logpol[inds], point[inds]], axis=1)  # dim=10
        # 针对point_coord的逆运算, center = (index+0.5) * intervals, 0-479 变为 1-480 变为 0 - 50, 并对\phi和z 平移回去
        # 不唯一
        point_voxel_centers = (point_coord.astype(np.float32) + 0.5) * intervals + min_bound  # 特征要加回平移min_bound
        if self.dim == 9:
            # 还有一种9没实现, 需要对比, point[:, :3]
            # 与voxel_feature 相比, 不需要n-to-1映射, 直接全部点参与计算, 坐标同样包含极坐标+迪卡尔
            point_feature = np.concatenate([point_voxel_centers, xyz_logpol, point[:, :2], point[:, 3:]], axis=1)
        else:
            point_feature = np.concatenate([point_voxel_centers, xyz_logpol, point], axis=1)  # dim=10
        # 注意,这里并没有对[坐标,特征] 进行SparseTenser的计算转化
        ret.update({
            'name': pc_data['path'],
            'point_feature': point_feature.astype(np.float32),  # 原点规模的[极坐标voxel的中心, 极坐标, 点x,y,r]
            'point_coord': point_coord.astype(np.float32),  # 原点规模的 [0:479, 0:359, 0:31]
            'point_label': point_label.astype(np.int32),  # 原点规模的 labels 直接读,没计算
            'voxel_feature': voxel_feature.astype(np.float32),  # 体素规模的 [极坐标voxel的中心, 极坐标, 点x,y,r]
            'voxel_coord': voxel_coord.astype(np.int32),  # 体素规模的 [0:479, 0:359, 0:31]
            'voxel_label': voxel_label.astype(np.int32),  # 体素规模的 labels, n-to-1
            'inverse_map': inverse_map.astype(np.int32),  # 每个点对应的体素索引
            'num_points': np.array([num_points_current_frame]),  # 当前帧点规模
        })

        return ret

    '''
    batch_list: list<dict> ---->
    data_dict ----> pad后存入下面, why
        |point_coord
        |voxel_coord
            ---->ret
    return ret
    '''
    @staticmethod
    def collate_batch(batch_list):
        # 遍历batch, 将数据存入data_dict @ container, 只是不会报KeyError
        data_dict = defaultdict(list)  # https://www.geeksforgeeks.org/defaultdict-in-python/
        for cur_sample in batch_list:
            for key, val in cur_sample.items():
                data_dict[key].append(val)
        batch_size = len(batch_list)
        # 遍历每个batch的初始数据, 并基于数据的point_coord 和 voxel_coord 计算
        ret = {}
        point_coord = []
        voxel_coord = []
        for i_batch in range(batch_size):  # 便利每个 batch_dict, 進行pad, 並分別添加到兩個list中
            #aaa = data_dict['point_coord'][i_batch]
            #bbb = np.pad(data_dict['point_coord'][i_batch], ((0, 0), (0, 1)), mode='constant', constant_values=i_batch)
            point_coord.append(  # ((before, after), (before, after)) each axis
                np.pad(data_dict['point_coord'][i_batch], ((0, 0), (0, 1)), mode='constant', constant_values=i_batch))
            voxel_coord.append(
                np.pad(data_dict['voxel_coord'][i_batch], ((0, 0), (0, 1)), mode='constant', constant_values=i_batch))
        # ndarray to Tensor
        ret['point_coord'] = torch.from_numpy(np.concatenate(point_coord)).type(torch.LongTensor)
        ret['voxel_coord'] = torch.from_numpy(np.concatenate(voxel_coord)).type(torch.LongTensor)

        ret['point_feature'] = torch.from_numpy(np.concatenate(data_dict['point_feature'])).type(torch.FloatTensor)
        ret['point_label'] = torch.from_numpy(np.concatenate(data_dict['point_label'])).type(torch.LongTensor)
        ret['voxel_feature'] = torch.from_numpy(np.concatenate(data_dict['voxel_feature'])).type(torch.FloatTensor)
        ret['voxel_label'] = torch.from_numpy(np.concatenate(data_dict['voxel_label'])).type(torch.LongTensor)
        ret['inverse_map'] = torch.from_numpy(np.concatenate(data_dict['inverse_map'])).type(torch.LongTensor)
        ret['num_points']= torch.from_numpy(np.concatenate(data_dict['num_points'])).type(torch.LongTensor)

        offset = [sample['voxel_coord'].shape[0] for sample in batch_list]
        ret['offset'] = torch.tensor(list(accumulate(offset))).int()
        ret['name'] = data_dict['name']

        for k, v in data_dict.items():
            if k.startswith('flag'):
                ret[k] = data_dict[k]
            elif k.startswith('augmented_point_coord'):  # 全局搜索似乎没看到augmented_point_coord相关配置,应该不会触发
                temp = []
                for i_batch in range(batch_size):
                    temp.append(
                        np.pad(data_dict[k][i_batch], ((0, 0), (0, 1)), mode='constant', constant_values=i_batch))
                ret[k] = torch.from_numpy(np.concatenate(temp)).type(torch.LongTensor)
            elif k.startswith('augmented_point_feature'):
                ret[k] = torch.from_numpy(np.concatenate(data_dict[k])).type(torch.FloatTensor)
            elif k.startswith('augmented_point_label') or k.startswith('augmented_inverse_map'):
                ret[k] = torch.from_numpy(np.concatenate(data_dict[k])).type(torch.LongTensor)

        return ret
    # unused
    @staticmethod
    def collate_batch_tta(batch_list):
        batch_list = batch_list[0]
        data_dict = defaultdict(list)
        for cur_sample in batch_list:
            for key, val in cur_sample.items():
                data_dict[key].append(val)
        batch_size = len(batch_list)
        ret = {}
        point_coord = []
        voxel_coord = []
        for i_batch in range(batch_size):
            point_coord.append(
                np.pad(data_dict['point_coord'][i_batch], ((0, 0), (0, 1)), mode='constant', constant_values=i_batch))
            voxel_coord.append(
                np.pad(data_dict['voxel_coord'][i_batch], ((0, 0), (0, 1)), mode='constant', constant_values=i_batch))

        ret['point_coord'] = torch.from_numpy(np.concatenate(point_coord)).type(torch.LongTensor)
        ret['voxel_coord'] = torch.from_numpy(np.concatenate(voxel_coord)).type(torch.LongTensor)

        ret['point_feature'] = torch.from_numpy(np.concatenate(data_dict['point_feature'])).type(torch.FloatTensor)
        ret['point_label'] = torch.from_numpy(np.concatenate(data_dict['point_label'])).type(torch.LongTensor)
        ret['voxel_feature'] = torch.from_numpy(np.concatenate(data_dict['voxel_feature'])).type(torch.FloatTensor)
        ret['voxel_label'] = torch.from_numpy(np.concatenate(data_dict['voxel_label'])).type(torch.LongTensor)
        ret['inverse_map'] = torch.from_numpy(np.concatenate(data_dict['inverse_map'])).type(torch.LongTensor)
        ret['num_points']= torch.from_numpy(np.concatenate(data_dict['num_points'])).type(torch.LongTensor)
        offset = [sample['voxel_coord'].shape[0] for sample in batch_list] 
        ret['offset'] = torch.tensor(list(accumulate(offset))).int()
        ret['name'] = data_dict['name']

        for k, v in data_dict.items():
            if k.startswith('flag'):
                ret[k] = data_dict[k]
            elif k.startswith('augmented_point_coord'):
                temp = []
                for i_batch in range(batch_size):
                    temp.append(
                        np.pad(data_dict[k][i_batch], ((0, 0), (0, 1)), mode='constant', constant_values=i_batch))
                ret[k] = torch.from_numpy(np.concatenate(temp)).type(torch.LongTensor)
            elif k.startswith('augmented_point_feature'):
                ret[k] = torch.from_numpy(np.concatenate(data_dict[k])).type(torch.FloatTensor)
            elif k.startswith('augmented_point_label') or k.startswith('augmented_inverse_map'):
                ret[k] = torch.from_numpy(np.concatenate(data_dict[k])).type(torch.LongTensor)

        return ret
