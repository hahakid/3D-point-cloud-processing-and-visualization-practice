import numpy as np
import open3d as o3d
#import mayavi_viz
import os
import yaml

def load_bin(velo_filename):
    scan = np.fromfile(velo_filename, dtype=np.float32)
    scan = scan.reshape((-1, 4))
    return scan

#@ *.yaml file format
def load_colormap(filename):
    DATA = yaml.safe_load(open(filename, 'r'))  # read yaml remapping
    remapdict = DATA["learning_map"]  # only 19-classes
    maxkey = max(remapdict.keys())
    remap_lut = np.zeros((maxkey + 100), dtype=np.int32)
    remap_lut[list(remapdict.keys())] = list(remapdict.values())
    # color_map

    #color_map_dict = DATA["color_map_new"]
    color_map_dict = DATA["color_map"]

    color_map = np.zeros((max(color_map_dict.keys()) + 1, 3), dtype=np.int32)
    color_map[list(color_map_dict.keys())] = list(color_map_dict.values())
    color_map = color_map/255.0# yaml-[0,255] open3d-[0,1]
    return color_map, remap_lut

def load_label(filename, remap):
    label = np.fromfile(filename, dtype=np.uint32)
    label = label.reshape((-1))
    lower_half = label & 0xFFFF  # get lower half for semantics
    label_list = remap[lower_half]  # do the remapping of semantics
    return label_list

def load_pclabel(pcfile,labelfile,remap):
    pc = load_bin(pcfile)
    label = load_label(labelfile, remap)
    assert len(pc[:, 0]) == len(label)
    label = label.reshape((-1, 1), order='F')
    return np.hstack((pc, label))

def load_label_colormap(filename,yamlfile):
    # load remapping from yaml
    DATA = yaml.safe_load(open(yamlfile, 'r'))#read yaml remapping
    remapdict = DATA["learning_map"]# 19-classes
    maxkey = max(remapdict.keys())
    remap_lut = np.zeros((maxkey + 100), dtype=np.int32)
    remap_lut[list(remapdict.keys())] = list(remapdict.values())
    #color_map
    color_map_dict= DATA["color_map_new"]
    color_map = np.zeros((max(color_map_dict.keys())+1, 3), dtype=np.int32)
    '''
    for i in color_map_dict.items():
        #print(i)
        #print('old_key=',i[0],' new_key=',remapdict[i[0]],' color=',i[1])
        color_map[remapdict[i[0]]]=i[1]
    '''
    color_map[list(color_map_dict.keys())] = list(color_map_dict.values())
    color_map=color_map/255.0

    # prepare labels
    label = np.fromfile(filename, dtype=np.uint32)
    label = label.reshape((-1))
    #upper_half = label >> 16  # get upper half for instances
    lower_half = label & 0xFFFF  # get lower half for semantics
    lower_half = remap_lut[lower_half]  # do the remapping of semantics
    #label = (upper_half << 16) + lower_half  # reconstruct full label
    #label = label.astype(np.uint32)
    #for l in lower_half:
    #    if l>19:
    #        print(l)
    return lower_half,color_map
    #label.tofile(filename)


def load_pcd(file):
    pcd = o3d.io.read_point_cloud(file)
    # o3d.visualization.draw_geometries([pcd])
    # color=np.asarray(pcd.colors)
    colors = np.asarray(pcd.colors) * 255
    points = np.asarray(pcd.points)
    return np.concatenate([points, colors], axis=-1)

#def show_reflect(file):
    #bin file in maya
#    pc_raw = load_bin(file)
#    mayavi_viz.viz_bin(pc_raw, 'reflect')

def show_label_open3d(file):
    vis = o3d.visualization.Visualizer()
    vis.create_window()
    pointcloud = o3d.io.read_point_cloud(file)
    opt = vis.get_render_option()
    opt.point_size = 1
    vis.add_geometry(pointcloud)
    vis.run()
    #vis.draw_geometries([pointcloud])
    vis.destroy_window()

def load_pc_with_label(pcfile,labelfile):
    pc=load_bin(pcfile)
    label,colormap=load_label_colormap(labelfile,'./data/semantic-kitti.yaml')
    assert len(pc[:,0]) == len(label)
    label=label.reshape((-1,1),order='F')
    return np.hstack((pc,label)), colormap
    #return np.asarray((pc[:,0],pc[:,1],pc[:,2],pc[:,3],label)).T,colormap

#'''
#pcl=load_pc_with_label('./000706.bin','./000706.label')
#print(type(pcl),pcl)
#'''