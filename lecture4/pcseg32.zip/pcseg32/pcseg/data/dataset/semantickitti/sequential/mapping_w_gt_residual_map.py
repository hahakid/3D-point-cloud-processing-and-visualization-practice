# -*- coding: UTF-8 -*-
import open3d as o3d
import numpy as np
from ..sequential import util
import glob
import os
import cv2
# import threading
import time
# import cv2
from collections import deque

# path = r'D:\data\SemanticKITTI\dataset'


 # 0-10


# color_map, remap = util.load_colormap('./data/semantic-kitti.yaml')
#color_map, remap = util.load_colormap(colormap_path)



# 3->2, 50->70
def range_projection(current_vertex, proj_H=64, proj_W=2048, fov_up=2.0, fov_down=-25.0, max_range=70.0, min_range=2.0):
    """ Project a pointcloud into a spherical projection, range image.
      Args:
        current_vertex: raw point clouds
      Returns:
        proj_vertex: each pixel contains the corresponding point (x, y, z, depth)
    """
    # laser parameters
    fov_up = fov_up / 180.0 * np.pi  # field of view up in radians
    fov_down = fov_down / 180.0 * np.pi  # field of view down in radians
    fov = abs(fov_down) + abs(fov_up)  # get field of view total in radians

    # get depth of all points
    depth = np.linalg.norm(current_vertex[:, :3], 2, axis=1)  # 2范数， axis=1: 基于行 sqrt(x^2+y^2)
    current_vertex = current_vertex[(depth > min_range) & (depth < max_range)]  # get rid of [0, 0, 0] points
    depth = depth[(depth > min_range) & (depth < max_range)]

    # get scan components, xyzi
    scan_x = current_vertex[:, 0]
    scan_y = current_vertex[:, 1]
    scan_z = current_vertex[:, 2]
    intensity = current_vertex[:, 3]

    # get angles of all points, bev=yaw,
    yaw = -np.arctan2(scan_y, scan_x)  # rad  arctan2(y/x)  horizontal
    pitch = np.arcsin(scan_z / depth)  # rad  arcsin( z / sqrt(x^2+y^2))  vertical

    # get projections in image coords
    proj_x = 0.5 * (yaw / np.pi + 1.0)  # in [0.0, 1.0]
    proj_y = 1.0 - (pitch + abs(fov_down)) / fov  # in [0.0, 1.0]

    # scale to image size using angular resolution
    proj_x *= proj_W  # in [0.0, W]  2048
    proj_y *= proj_H  # in [0.0, H]  64

    # round and clamp for use as index
    proj_x = np.floor(proj_x)  # 取整
    proj_x = np.minimum(proj_W - 1, proj_x)  # idx=[0, W-1]
    proj_x = np.maximum(0, proj_x).astype(np.int32)  # in [0,W-1]

    proj_y = np.floor(proj_y)
    proj_y = np.minimum(proj_H - 1, proj_y)
    proj_y = np.maximum(0, proj_y).astype(np.int32)  # in [0,H-1]

    # order in decreasing depth
    order = np.argsort(depth)[::-1]
    depth = depth[order]

    proj_y = proj_y[order]
    proj_x = proj_x[order]

    indices = np.arange(depth.shape[0])
    indices = indices[order]

    proj_range = np.full((proj_H, proj_W), -1, dtype=np.float32)  # [H,W] range (-1 is no data)
    proj_idx = np.full((proj_H, proj_W), -1, dtype=np.int32)  # [H,W] index (-1 is no data)
    proj_range[proj_y, proj_x] = depth  # depth (=sqrt(x^2+y^2) map  # [W, H, 1]
    proj_idx[proj_y, proj_x] = indices  # -1为无数据的，其余为index
    proj_mask = (proj_idx > 0).astype(np.int32)  # 非全0

    return proj_range, proj_mask


def rigid_translate(pc_input, extrinsic):
    # projection
    pc = np.hstack((pc_input[:, :3], np.ones_like(pc_input[:, 0]).reshape(-1, 1)))  # label=1
    pc = np.matmul(extrinsic, pc.T).T  # np.matmul(extrinsic, pc).T
    pcl = np.hstack((pc[:, :3], pc_input[:, 3:]))
    return pcl

def colored_pc(pcl, colormap):
    color = []
    labels = pcl[:, 4]
    for l in labels:
        color.append(colormap[int(l)])
    color = np.asarray(color)
    colored_pointcloud = o3d.geometry.PointCloud()
    colored_pointcloud.points = o3d.utility.Vector3dVector(pcl[:, 0:3])  # xyz
    colored_pointcloud.colors = o3d.utility.Vector3dVector(color)  # color
    return colored_pointcloud


def show_pc_with_label(pcl, label_index, cmap):
    g_label = pcl[pcl[:, 4] == label_index]
    cpc = colored_pc(g_label, cmap)
    simple_show(cpc)

def parse_calibration(filename):
    """ read calibration file with given filename

        Returns
        -------
        dict
            Calibration matrices as 4x4 numpy arrays.
    """
    calib = {}

    calib_file = open(filename)
    for line in calib_file:
        key, content = line.strip().split(":")
        values = [float(v) for v in content.strip().split()]

        pose = np.zeros((4, 4))
        pose[0, 0:4] = values[0:4]
        pose[1, 0:4] = values[4:8]
        pose[2, 0:4] = values[8:12]
        pose[3, 3] = 1.0

        calib[key] = pose

    calib_file.close()

    return calib

def simple_show(data):
    vis = o3d.visualization.Visualizer()
    vis.create_window(width=1280, height=720)
    opt = vis.get_render_option()
    opt.point_size = 1
    vis.add_geometry(data)
    vis.run()
    vis.destroy_window()


def pc_show(pc, norm_flag=False):
    vis = o3d.visualization.Visualizer()
    vis.create_window(width=1280, height=720)
    opt = vis.get_render_option()
    opt.point_size = 3
    opt.point_show_normal = norm_flag
    for p in pc:
        vis.add_geometry(p)
    vis.run()
    vis.destroy_window()

def parse_poses(filename, calibration):
    """ read poses file with per-scan poses from given filename

        Returns
        -------
        list
            list of poses as 4x4 numpy arrays.
    """
    file = open(filename)

    poses = []

    Tr = calibration["Tr"]
    Tr_inv = np.linalg.inv(Tr)

    for line in file:
        values = [float(v) for v in line.strip().split()]

        pose = np.zeros((4, 4))
        pose[0, 0:4] = values[0:4]
        pose[1, 0:4] = values[4:8]
        pose[2, 0:4] = values[8:12]
        pose[3, 3] = 1.0

        poses.append(np.matmul(Tr_inv, np.matmul(pose, Tr)))

    return poses

def merge_pc(mpc, cpc):
    if np.asarray(mpc.points).shape[0] == 0:
        # mpc.points = cpc.points
        # mpc.colors = cpc.colors
        mpc = cpc
    else:
        merged_pc = np.asarray(mpc.points)
        merged_color = np.asarray(mpc.colors)
        current_pc = np.asarray(cpc.points)
        current_color = np.asarray(cpc.colors)

        merged_pc = np.vstack((merged_pc, current_pc))
        merged_color = np.vstack((merged_color, current_color))

        mpc.points = o3d.utility.Vector3dVector(merged_pc)
        mpc.colors = o3d.utility.Vector3dVector(merged_color)

    return mpc

if __name__ == '__main__':
    # -----init------------------------
    seq = 4
    max_range = 70.0
    min_range = 2.0

    path = r"H:\学习\Cylinder\SemanticKITTI\dataset"
    colormap_path = r'H:\学习\Cylinder\SemanticKITTI\dataset/semantic-kitti.yaml'

    # ----------------------------
    pc_list = os.listdir(os.path.join(path, 'velodyne', str(seq).zfill(2)))       # seq只用了4
    # label_list = os.listdir(os.path.join(path, 'labels', str(seq).zfill(2)))
    # pose_list = os.path.join(path, 'poses', str(seq).zfill(2)+'.txt')
    # print(pc_list, label_list, pose_list)
    calib_path = os.path.join(path, 'calib', str(seq).zfill(2), 'calib.txt')  # 每个seq，对应一个calib文件
    calib = parse_calibration(calib_path)  # only use calib['Tr'] for IMU-Velodyne External reference
    poses = parse_poses(os.path.join(path, 'poses', str(seq).zfill(2)+".txt"), calib)  # 每个seq，对应一个pose文件，每行对应一帧

    color_map, remap = util.load_colormap(colormap_path)

    # history = deque()
    # queue_len = 2  # queue length for registration continues PC

    for i in range(10, len(pc_list)):  # from [1:n], t-1 & t
        residual_image = np.full((64, 2048), 0, dtype=np.float32)
        hsv = np.zeros_like(np.full((64, 2048, 3), 0, dtype=np.float32))
        # t
        pc_path_i = os.path.join(path, 'velodyne', str(seq).zfill(2), pc_list[i])
        label_path_i = pc_path_i.replace('velodyne', 'labels').replace('.bin', '.label')
        pcl_i = util.load_pclabel(pc_path_i, label_path_i, remap)  # return pc with label_idx=[xyzrl] as global
        # cpc_i = colored_pc(pcl_i, color_map)  # colored point cloud [i]

        # t-1
        pc_path_j = os.path.join(path, 'velodyne', str(seq).zfill(2), pc_list[i-1])
        label_path_j = pc_path_j.replace('velodyne', 'labels').replace('.bin', '.label')
        pcl_j = util.load_pclabel(pc_path_j, label_path_j, remap)  # return pc with label_idx=[xyzrl] # local
        # cpc_j = colored_pc(pcl_j, color_map)  # colored point cloud [i]
        # 将pc[t-1] 投影到 当前帧 pc[t] 所在的坐标系下
        diff_pose = np.matmul(np.linalg.inv(poses[i]), poses[i-1])
        pc_j = rigid_translate(pcl_j, diff_pose)  # to global

        rm_i, mask_i = range_projection(pcl_i.astype(np.float32))
        rm_j, mask_j = range_projection(pcl_j.astype(np.float32))

        valid_mask = (rm_i > min_range) & \
                     (rm_i < max_range) & \
                     (rm_j > min_range) & \
                     (rm_j < max_range)
        # normalized
        residual_image[valid_mask] = np.abs(rm_i[valid_mask] - rm_j[valid_mask]) / rm_i[valid_mask]  # abs(i-j) / i
        #difference = np.abs(rm_i - rm_j) / rm_i  # abs(i-j) / i
        '''
        dense optical flow:
        @ previous frame
        @ current frame
        @ output=None, 通过返回值，而非参数
        @ pyr_scale=0.5 classical pyramid, where each next layer is twice smaller than the previous one.
        @ levels = 2 number of pyramid layers including the initial image; levels=1 means that no extra layers
        @ winsize = 3 # averaging window size; need reduce
        @ iterations = 3 # number of iterations the algorithm does at each pyramid level.
        @ poly_n=5 # size of the pixel neighborhood used to find polynomial expansion in each pixel; larger values mean that the image will be approximated with smoother surfaces, yielding more robust algorithm and more blurred motion field, 
        @ poly_sigma=1.2 standard deviation of the Gaussian that is used to smooth derivatives used as a basis for the polynomial expansion; for poly_n=5, you can set poly_sigma=1.1, for poly_n=7, a good value would be poly_sigma=1.5.
        @ flags=0
        '''
        flow = cv2.calcOpticalFlowFarneback(rm_j, rm_i, None, 0.5, 1, 2, 1, 2, 1.1, 0)
        mag, ang = cv2.cartToPolar(flow[:, :, 0], flow[:, :, 1])  # flow contains negative values
        hsv[..., 0] = ang * 180/np.pi/2
        hsv[..., 1] = 255 * np.ones_like(residual_image)
        # HSV 2 GRAY ??
        # ang = cv2.normalize(ang, None, 0, 255, cv2.NORM_MINMAX)
        hsv[..., 2] = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX)
        of = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
        # of = cv2.cvtColor(cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB), cv2.COLOR_RGB2GRAY)
        cv2.imshow('t', rm_i)
        cv2.imshow('t-1', rm_j)
        cv2.imshow('residual', residual_image)
        cv2.imshow('flow-ang', of)
        # cv2.imshow('flow-mag', mag)
        cv2.waitKey()
    cv2.destroyAllWindows()

