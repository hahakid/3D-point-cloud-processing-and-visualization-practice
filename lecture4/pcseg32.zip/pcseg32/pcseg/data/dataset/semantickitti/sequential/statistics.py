import numpy as np
import util
from visualization import list_path
from visualization import pose_init
from visualization import j_to_i_project
from mapping_w_gt_residual_map import range_projection
import matplotlib.pyplot as plt


def draw_chart(residual_image, mask_t_1):
    residual_image = residual_image[mask_t_1 == 1]
    hist, bin_edges = np.histogram(residual_image, bins=100,)


    plt.bar(
        bin_edges[:-1],
        hist,
        color="c",
        width=0.1
    )

    plt.xlabel("residual")
    plt.ylabel("Frequence")
    plt.title("residual distribution")
    plt.show()

    # ----------draw-------------------
    '''
    plt.hist(hist, bins=100, range=[0, 3])
    # plt.hist(hist, bins=100, color="skyblue", edgecolor="black")
    
    
    '''
    '''
    bar = (
        Bar()
        .add_xaxis([str(x) for x in bin_edges[:-1]])
        .add_yaxis("分布", [float(x) for x in hist], category_gap=0)
        .set_global_opts(
            title_opts=opts.TitleOpts(title="残差分布",pos_left="center"),
        )
    )

    bar.render()
    '''
    print()

def get_t_residual(data_root, frame_t, pose_list, point_list):
    max_range = 70.0
    min_range = 2.0

    # =====================================================
    residual_image = np.full((64, 2048), 0, dtype=np.float32)

    pcl1 = util.load_pclabel(point_list[frame_t-1], label_list[frame_t-1], remap)
    pcl2 = util.load_pclabel(point_list[frame_t], label_list[frame_t], remap)
    pose1 = pose_list[frame_t-1]
    pose2 = pose_list[frame_t]
    pcl1 = j_to_i_project(pcl1, pose1, pose2)

    rm1, mask1 = range_projection(pcl1.astype(np.float32))
    rm2, mask2 = range_projection(pcl2.astype(np.float32))

    valid_mask = (rm1 > min_range) & \
                 (rm1 < max_range) & \
                 (rm2 > min_range) & \
                 (rm2 < max_range)
    # normalized
    residual_image[valid_mask] = np.abs(rm1[valid_mask] - rm2[valid_mask]) / rm2[valid_mask]  # abs(i-j) / i

    return residual_image, mask1

def draw_line(draw_x, add_num_list):
    #draw_x = np.arange(len(point_list))
    #add_num_list = np.random.normal(0.2, 1, 19130)


    # --draw
    plt.scatter(draw_x, add_num_list, s=1)

    plt.title('Scale of Increased Points')
    plt.xlabel("Frame")
    plt.ylabel("Scale/percent")

    plt.show()


if __name__ == "__main__":
    # init ==========================================
    train_set = ['00', '01', '02', '03', '04', '05', '06', '07', '09', '10']
    data_root = "/mnt/data3/data_root/SemanticKITTI/dataset/"
    color_map, remap = util.load_colormap(r'/mnt/data3/data_root/SemanticKITTI/dataset/semantic-kitti.yaml')
    point_list, label_list = list_path(data_root, train_set)
    pose_list = pose_init(data_root, train_set)
    #=================================================
    add_num_list = np.zeros(len(point_list))
    draw_x = np.arange(len(point_list))

    time = 0
    error = 0
    for i in range(1, len(point_list)):

        if point_list[i][-10: -4] == "000000":
            continue

        if i % 191 == 0:
            time += 1
            print(time)


        residual_image, maskt_1 = get_t_residual(data_root, i, pose_list, point_list)
        residual_image_add_avaliable = residual_image[maskt_1 == 1]                     # t-1帧里存在的点，是待增加的点

        point_num = len(residual_image_add_avaliable)                                   # 待增加的点所有个数
        bias = 0.02                                                                     # 差异区间0.02

        judge = residual_image_add_avaliable > 0.02
        point_add = residual_image_add_avaliable[judge]
        point_num_add = len(point_add)
        if point_num == 0:
            error += 1
            with open("log.txt", 'a') as f:
                f.write(str(i)+'\n')
            continue
        add_num_list[i] = point_num_add/point_num

        # draw_chart(residual_image, maskt_1)
        #print(i)
    draw_line(draw_x, add_num_list*100)









    print()

