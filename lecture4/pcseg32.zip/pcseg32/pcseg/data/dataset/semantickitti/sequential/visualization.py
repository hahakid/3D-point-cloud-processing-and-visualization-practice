# -*- coding: UTF-8 -*-
import open3d as o3d
import numpy as np
from ..sequential import util
import os
from ..sequential.mapping_w_gt_residual_map import parse_calibration
from ..sequential.mapping_w_gt_residual_map import parse_poses
from ..sequential.mapping_w_gt_residual_map import rigid_translate
from ..PolarMix_semantickitti import polarmix
from ..LaserMix_semantickitti import lasermix_aug


def colored_pc(pcl, colormap):
    color = []
    labels = pcl[:, 4]
    for l in labels:
        color.append(colormap[int(l)])
    color = np.asarray(color)
    colored_pointcloud = o3d.geometry.PointCloud()
    colored_pointcloud.points = o3d.utility.Vector3dVector(pcl[:, 0:3])
    colored_pointcloud.colors = o3d.utility.Vector3dVector(color)
    return colored_pointcloud
#引入open3d库，获取点云的标签信息，并将其导入open3d的格式（导入其三维坐标以及color信息）
#vector3dVector是一个储存三维向量（即点的坐标）的类
#utility是一个工具类，包括了一些对点云数据的处理函数
#colormap是一个预定义的颜色映射表（color map），用于将点云数据中的标签（labels）映射到相应的颜色。

def simple_show(data):
    vis = o3d.visualization.Visualizer()
    vis.create_window(width=800, height=600)
    opt = vis.get_render_option()#render意为渲染
    opt.point_size = 1 #设置点的大小
    vis.add_geometry(data) #添加点云
    vis.run() #运行
    vis.destroy_window() #关闭窗口
#显示点云，并设置点的大小


def show_pcl(pcl, data_root):
    color_map, remap = util.load_colormap(data_root+'/semantic-kitti.yaml')
    cpc = colored_pc(pcl, color_map)
    simple_show(cpc)

def list_path(data_root, train_set):
    f_list = []
    for i in train_set:
        tmp_list = os.listdir(os.path.join(data_root, "velodyne", i))
        for idx in range(len(tmp_list)):
            tmp_list[idx] = os.path.join(data_root, "velodyne", i, tmp_list[idx])
        f_list += tmp_list

    lb_list = []
    for i in f_list:
        lb_list.append(i.replace("velodyne", "labels").replace(".bin", ".label"))

    f_list.sort()
    lb_list.sort()
    return f_list, lb_list


def j_to_i_project(point_j, pose_j, pose_i):
    diff_pose = np.matmul(np.linalg.inv(pose_i), pose_j)
    pc_j = rigid_translate(point_j, diff_pose)
    return pc_j


def pose_init(data_root, train_set):
    calib = {}
    pose = []
    for seq in train_set:
        calib_path = os.path.join(data_root, "calib", seq, "calib.txt")
        calib[seq] = parse_calibration(calib_path)
        pose += parse_poses(os.path.join(data_root, 'poses', seq + ".txt"), calib[seq])
    return pose


def show_project(index, point_list, pose_list):
    pcl1 = util.load_pclabel(point_list[index - 1], label_list[index - 1], remap)
    pcl2 = util.load_pclabel(point_list[index], label_list[index], remap)
    pose1 = pose_list[index - 1]
    pose2 = pose_list[index]
    pcl1 = j_to_i_project(pcl1, pose1, pose2)

    pcl3 = np.concatenate((pcl1, pcl2), axis=0)

    show_pcl(pcl1, data_root)
    show_pcl(pcl2, data_root)
    show_pcl(pcl3, data_root)


def project_t_1(dataroot, index, point1, label1, point2, label2, pose_list):
    pcl1 = np.concatenate((point1[..., 0:4], label1), axis=1)
    pcl2 = np.concatenate((point2[..., 0:4], label2), axis=1)

    #pcl1 = util.load_pclabel(point_list[index - 1], label_list[index - 1], remap)
    #pcl2 = util.load_pclabel(point_list[index], label_list[index], remap)
    pose1 = pose_list[index - 1]
    pose2 = pose_list[index]
    pcl1 = j_to_i_project(pcl1, pose1, pose2)

    pcl3 = np.concatenate((pcl1, pcl2), axis=0)


    # show_pcl(pcl1, data_root)
    # show_pcl(pcl2, data_root)
    # show_pcl(pcl3, data_root)
    ringid = np.concatenate((pcl1[..., 4], pcl2[:, 4]), axis=0).reshape(-1, 1)
    point = np.concatenate((pcl3[..., 0:4], ringid), axis=1)
    label = pcl3[:, 4].reshape(-1, 1)

    return point, label


if __name__ == "__main__":
    # ------init------------------------------------------------------
    AUGMENT_METHOD = "polar_mix"        #laser_mix/polar_mix
    train_set = ['00', '01', '02', '03', '04', '05', '06', '07', '09', '10']
    data_root = r"H:\学习\Cylinder\SemanticKITTI\dataset"
    yaml_path = r"H:\学习\Cylinder\SemanticKITTI\dataset\semantic-kitti.yaml"
    color_map, remap = util.load_colormap(yaml_path)
    point_list, label_list = list_path(data_root, train_set)
    pose_list = pose_init(data_root, train_set)


    #======投影可视化===========================================
    #index = 11334
    #show_project(index, point_list, pose_list)

    #======数据增强可视化===============================================
    frame = 11334     #当前帧
    pcl1 = util.load_pclabel(point_list[frame], label_list[frame], remap)
    point = pcl1[..., 0:4]
    label = pcl1[..., 4].reshape(-1, 1)

    other_frame = np.random.randint(0, len(point_list))
    pcl2 = util.load_pclabel(point_list[other_frame], label_list[other_frame], remap)
    other_point = pcl2[..., 0:4]
    other_label = pcl2[..., 4].reshape(-1, 1)

    # polar_mix
    # -------init---------
    if AUGMENT_METHOD == "polar_mix":
        Omega = [np.random.random() * np.pi * 2 / 3, (np.random.random() + 1) * np.pi * 2 / 3]
        instance_classes = [1, 2, 3, 4, 5, 6, 7, 8]
        alpha = (np.random.random() - 1) * np.pi
        beta = alpha + np.pi
        label = label.reshape(-1)
        other_label = other_label.reshape(-1)
        # --------aug----------
        point_aug, label_aug = polarmix(
            point, label, other_point, other_label,
            alpha=alpha, beta=beta,
            instance_classes=instance_classes, Omega=Omega
        )
        label_aug = label_aug.reshape(-1, 1)

    elif AUGMENT_METHOD == "laser_mix":
        point_aug, label_aug = lasermix_aug(
            point,
            label,
            other_point,
            other_label,
        )


    # ------show---------
    show_pcl(pcl1, data_root)              # 增强之前
    pcl_aug = np.concatenate((point_aug, label_aug), axis=1)
    show_pcl(pcl_aug, data_root)           # 增强之后

    #test========================

    #show_project(frame, point_list, pose_list)
    print()

