'''
Reference:
    [1] https://github.com/NVIDIA/MinkowskiEngine
    [2] https://github.com/mit-han-lab/spvnas
'''


import torchsparse
import torchsparse.nn as spnn
import torch
from torch import nn
from torchsparse import PointTensor
from pcseg.model.segmentor.base_segmentors import BaseSegmentor
from torchsparse import SparseTensor
from torchsparse.nn.utils import fapply
from .utils import initial_voxelize, voxel_to_point
from pcseg.loss import Losses


__all__ = ['MinkUNet']


# The mean and standard-deviation are calculated per-dimension over all mini-batches of the same process groups.
class SyncBatchNorm(nn.SyncBatchNorm):  # multi-GPU
    def forward(self, input: SparseTensor) -> SparseTensor:
        return fapply(input, super().forward)


# Applies Batch Normalization over a 2D or 3D input
class BatchNorm(nn.BatchNorm1d):  # single-GPU
    def forward(self, input: SparseTensor) -> SparseTensor:
        return fapply(input, super().forward)


# spnn.Conv3d
class BasicConvolutionBlock(nn.Module):
    def __init__(
        self,
        inc: int,
        outc: int,
        ks: int = 3,
        stride: int = 1,
        dilation: int = 1,  # 无空洞, 传统卷积
        if_dist: bool = False,  # True=on multi-GPU
    ):
        super().__init__()
        self.net = nn.Sequential(
            spnn.Conv3d(   # conv ks可调, stride 可调, 一般情况下应该是 featuremap变小/不变 + inc <= outc
                inc, outc,
                kernel_size=ks,
                dilation=dilation,  # 无空洞, 传统卷积
                stride=stride,
            ),
            SyncBatchNorm(outc) if if_dist else BatchNorm(outc),
            spnn.ReLU(True),
        )

    def forward(self, x):
        out = self.net(x)
        return out

# spnn.Conv3d, transposed=True = deConv3d / ConvTranspose3d (named in pytorch)
# https://torchsparse-docs.github.io/reference/torchsparse.nn.functional.html#torchsparse.nn.functional.conv.conv3d
class BasicDeconvolutionBlock(nn.Module):
    def __init__(
        self,
        inc: int,
        outc: int,
        ks: int = 3,
        stride: int = 1,
        if_dist: bool = False,
    ):
        super().__init__()
        self.net = nn.Sequential(
            spnn.Conv3d(  # conv ks可调, stride 可调, 一般情况下应该是 featuremap变大 + inc > outc
                inc, outc,
                kernel_size=ks,
                stride=stride,
                transposed=True,  # 逆卷积, differ from https://pytorch.org/docs/1.13/nn.html
            ),
            SyncBatchNorm(outc) if if_dist else BatchNorm(outc),
            spnn.ReLU(True),
        )

    def forward(self, x):
        return self.net(x)

# https://github.com/pytorch/vision/blob/main/torchvision/models/resnet.py
# https://github.com/pytorch/vision/blob/main/torchvision/models/resnet.py#L115
class ResidualBlock(nn.Module):
    expansion = 1  # 总是1? # 在官方代码中 basicBlock 为1, bottleneck 为4
    # 用来对输出卷积核规模进行放缩
    def __init__(
        self,
        inc: int,
        outc: int,
        ks: int = 3,
        stride: int = 1,
        dilation: int = 1,
        if_dist: bool = False,
    ):
        super().__init__()
        self.net = nn.Sequential(  # Conv3d + BN + ReLU +Conv3d + BN
            spnn.Conv3d(  # 3*3 conv
                inc, outc,
                kernel_size=ks,  # conv ks可调, stride可调
                dilation=dilation,
                stride=stride,
            ),
            SyncBatchNorm(outc) if if_dist else BatchNorm(outc),
            spnn.ReLU(True),
            spnn.Conv3d(    # conv ks可调, stride=1固定,
                outc, outc,
                kernel_size=ks,
                dilation=dilation,
                stride=1,
            ),
            SyncBatchNorm(outc) if if_dist else BatchNorm(outc),
        )
        # Residual = downsample + ReLU
        '''
        Downsample  + ReLU
        1) 输入==输出 and stride=1: downsample= nn.identity()
        2) 否则: downsample= Conv3d+BN, 卷积核固定使用1*1*1, stride可调
        '''
        # identity()
        if inc == outc * self.expansion and stride == 1:  # 保持featuremap不变
            self.downsample = nn.Identity()  # https://pytorch.org/docs/stable/generated/torch.nn.Identity.html#torch.nn.Identity
        else:  # projections
            self.downsample = nn.Sequential(  # featuremap发生改变
                spnn.Conv3d(  # ks=1固定, stride!=1 时的情况
                    inc, outc * self.expansion,
                    kernel_size=1,
                    dilation=1,
                    stride=stride,
                ),
                SyncBatchNorm(outc * self.expansion) if if_dist else BatchNorm(outc * self.expansion),
            )
        self.relu = spnn.ReLU(True)

    def forward(self, x):
        out = self.relu(self.net(x) + self.downsample(x))
        return out


class Bottleneck(nn.Module):
    expansion = 4  # 在官方代码中 basicBlock 为1, bottleneck 为4

    def __init__(
        self,
        inc: int,
        outc: int,
        ks: int = 3,
        stride: int = 1,
        dilation: int = 1,
        if_dist: bool = False,
    ):
        super().__init__()
        self.net = nn.Sequential(
            spnn.Conv3d(  # conv ks=1固定, stride=1 默认
                inc, outc,
                kernel_size=1,
                bias=False,
            ),
            SyncBatchNorm(outc) if if_dist else BatchNorm(outc),
            spnn.Conv3d(  # conv ks可调, stride可调
                outc, outc,
                kernel_size=ks,
                stride=stride,
                bias=False,
                dilation=dilation,
            ),
            SyncBatchNorm(outc) if if_dist else BatchNorm(outc),
            spnn.Conv3d(  # conv ks=1 固定, stride=1 默认
                outc, outc * self.expansion,
                kernel_size=1,
                bias=False,
            ),
            SyncBatchNorm(outc * self.expansion) if if_dist else BatchNorm(outc * self.expansion),  # 倍增
        )
        if inc == outc * self.expansion and stride == 1:
            self.downsample = nn.Identity()
        else:
            self.downsample = nn.Sequential(
                spnn.Conv3d(  # conv ks=1 固定, stride可调
                    inc, outc * self.expansion,  #
                    kernel_size=1,
                    dilation=1,
                    stride=stride,
                ),
                SyncBatchNorm(outc * self.expansion) if if_dist else BatchNorm(outc * self.expansion),
            )
        self.relu = spnn.ReLU(True)

    def forward(self, x):
        out = self.relu(self.net(x) + self.downsample(x))
        return out


class MinkUNet(BaseSegmentor):    
    def __init__(
        self,
        model_cfgs,
        num_class: int,
    ):
        super().__init__(model_cfgs, num_class)
        self.in_feature_dim = model_cfgs.IN_FEATURE_DIM
        self.num_layer = model_cfgs.get('NUM_LAYER', [2, 3, 4, 6, 2, 2, 2, 2])
        self.block = {  # 基于yaml配置,二选一, 没有配置文件对第二个进行选择的
            'ResBlock': ResidualBlock,
            'Bottleneck': Bottleneck,
        }[model_cfgs.get('BLOCK', 'Bottleneck')]  # BLOCK: ResBlock, Bottleneck undefined

        cr = model_cfgs.get('cr', 1.0)
        cs = model_cfgs.get('PLANES', [32, 32, 64, 128, 256, 256, 128, 96, 96])
        #                              16, 16, 32, 64,  128, 128, 64,  48, 48
        #                           cs: 0,  1,  2,  3,    4,   5,  6,   7,  8
        #                             stem=16
        #                                stage1=16
        #                                     stage2=32
        #                                         stage3=64
        #                                              stage4=128
        #                                                 up1=stage4->cs5, up1=up1+stage3=128+64, up1->cs5
        #                                                      up2=up1->cs6, up2=up2+stage2=64+32=96, up2->cs6
        #                                                          up3=up2->cs7, up3=up3+stage1=48+16=64, up3->cs7
        #                                                                up4=up3->cs8, up4=up4+stage0=48+16=64, up4->cs8
        #                           classifier = cs4 + cs6 + cs8=128+64+48=240 --> # of class=20  # 相当于每个voxel最后有240维feature. 预测一个归一化的20维向量

        cs = [int(cr * x) for x in cs]  # update cs based on cr
        # for initial_voxelize()
        self.pres = model_cfgs.get('pres', 0.05)  # yaml 也没有这两个参数,应该就这样默认了, 但是匹配了VOXEL_SIZE: 0.05, 但实际上,只在数据计算时用来计算特征了,与这边没关系
        self.vres = model_cfgs.get('vres', 0.05)
        # 开始定义模型架构
        self.stem = nn.Sequential(  # stem, A sequential container. Modules will be added to it in the order they are passed in the constructor. Alternatively, an ordered dict of modules can also be passed in.
            spnn.Conv3d(  # 1 稀疏-3d卷积, @input_c, @output_c, @kernel, @stride
                self.in_feature_dim, cs[0],  # input and first layer
                kernel_size=3,
                stride=1,
            ),
            SyncBatchNorm(cs[0]) if model_cfgs.IF_DIST else BatchNorm(cs[0]),  # 2 single GPU IF_DIST=False
            spnn.ReLU(True),  # 3
            spnn.Conv3d(  # 4
                cs[0], cs[0],  # Num of filter for input, output
                kernel_size=3,
                stride=1,
            ),
            SyncBatchNorm(cs[0]) if model_cfgs.IF_DIST else BatchNorm(cs[0]),  # 4
            spnn.ReLU(True),  # 5
        )

        self.in_channels = cs[0]  # as out from stem
        if_dist = model_cfgs.IF_DIST  # 多卡/分布式flag

        self.stage1 = nn.Sequential(
            BasicConvolutionBlock(  # 1, 特征图降采样
                self.in_channels, self.in_channels,
                ks=2,
                stride=2,
                dilation=1,
                if_dist=model_cfgs.IF_DIST,
            ),
            *self._make_layer(  # [ResidualBlock, out, layer#]
                self.block, cs[1], self.num_layer[0], if_dist=if_dist),
        )
        self.stage2 = nn.Sequential(
            BasicConvolutionBlock(  # 1, 特征图降采样
                self.in_channels, self.in_channels,
                ks=2,
                stride=2,
                dilation=1,
                if_dist=model_cfgs.IF_DIST,
            ),
            *self._make_layer(
                self.block, cs[2], self.num_layer[1], if_dist=if_dist),
        )
        self.stage3 = nn.Sequential(
            BasicConvolutionBlock(  # 1, 特征图降采样
                self.in_channels, self.in_channels,
                ks=2,
                stride=2,
                dilation=1,
                if_dist=model_cfgs.IF_DIST,
            ),
            *self._make_layer(
                self.block, cs[3], self.num_layer[2], if_dist=if_dist),
        )
        self.stage4 = nn.Sequential(
            BasicConvolutionBlock(  # 1, 特征图降采样
                self.in_channels, self.in_channels,
                ks=2,
                stride=2,
                dilation=1,
                if_dist=model_cfgs.IF_DIST,
            ),
            *self._make_layer(
                self.block, cs[4], self.num_layer[3], if_dist=if_dist),
        )

        self.up1 = [
            BasicDeconvolutionBlock(
                self.in_channels, cs[5],  # 输出
                ks=2,
                stride=2,
                if_dist=model_cfgs.IF_DIST,
            )
        ]
        # 跨层链接输入, 但是还没有组装,只是定义, 第一次修改? print了试试看 每个定义完之后
        self.in_channels = cs[5] + cs[3] * self.block.expansion  # 基于 block的类型 确定1/4
        self.up1.append(
            nn.Sequential(*self._make_layer(
                self.block, cs[5], self.num_layer[4], if_dist=if_dist))
        )
        self.up1 = nn.ModuleList(self.up1)  # Holds submodules in a list., 不过子模块只用了up1一个, 可能在fusion用了

        self.up2 = [
            BasicDeconvolutionBlock(
                self.in_channels, cs[6],
                ks=2,
                stride=2,
                if_dist=model_cfgs.IF_DIST,
            )
        ]
        # 跨层链接输入, 但是还没有组装,只是定义.
        self.in_channels = cs[6] + cs[2] * self.block.expansion
        self.up2.append(
            nn.Sequential(*self._make_layer(
                self.block, cs[6], self.num_layer[5], if_dist=if_dist))
        )
        self.up2 = nn.ModuleList(self.up2)

        self.up3 = [
            BasicDeconvolutionBlock(
                self.in_channels, cs[7],
                ks=2,
                stride=2,
                if_dist=model_cfgs.IF_DIST,
            )
        ]
        # 跨层链接输入, 但是还没有组装,只是定义.
        self.in_channels = cs[7] + cs[1] * self.block.expansion
        self.up3.append(
            nn.Sequential(*self._make_layer(
                self.block, cs[7], self.num_layer[6], if_dist=if_dist))
        )
        self.up3 = nn.ModuleList(self.up3)

        self.up4 = [
            BasicDeconvolutionBlock(
                self.in_channels, cs[8],
                ks=2,
                stride=2,
                if_dist=model_cfgs.IF_DIST,
            )
        ]
        # 跨层链接输入, 但是还没有组装,只是定义.
        self.in_channels = cs[8] + cs[0]
        self.up4.append(
            nn.Sequential(*self._make_layer(
                self.block, cs[8], self.num_layer[7], if_dist=if_dist))
        )
        self.up4 = nn.ModuleList(self.up4)
        # 最终分类器包含了 三个层的输入? 只定义,未组装
        self.classifier = nn.Sequential(
            # 这里改成组合后进行卷积?会不会好点
            # 1. 通过卷积映射到相同的feature map
            # 2. 像RPVNet一样,选择: 累加, 拼接, Gated Fusion中的一种,进行特征聚合
            # 3. 卷积处理一下
            # 4. linear()到最后输出
            nn.Linear((cs[4] + cs[6] + cs[8]) * self.block.expansion, self.num_class)
        )

        self.weight_initialization()  # 网络参数初始化
        # 配置随机丢弃率
        dropout_p = model_cfgs.get('DROPOUT_P', 0.3)  # 目前配置0.0, 虽然在这里配置,但是在后面组装才会使用,只在部分层进行丢弃
        self.dropout = nn.Dropout(dropout_p, True)  # 这个只是随机丢弃输入tensor(置为0), 使用Bernoulli分布

        label_smoothing = model_cfgs.get('LABEL_SMOOTHING', 0.0)  # 该参数0.1 没有进行相关分析,阅读了原论文

        # loss, 抽空看明白,还没看
        default_loss_config = {  # only a dict
            'LOSS_TYPES': ['CELoss', 'LovLoss'],
            'LOSS_WEIGHTS': [1.0, 1.0],
            'KNN': 10,
        }

        # yaml文件均为None, 所以载入上面的默认
        loss_config = self.model_cfgs.get('LOSS_CONFIG', default_loss_config)  # dict

        # 读取默认参数
        loss_types = loss_config.get('LOSS_TYPES', default_loss_config['LOSS_TYPES'])
        loss_weights = loss_config.get('LOSS_WEIGHTS', default_loss_config['LOSS_WEIGHTS'])
        assert len(loss_types) == len(loss_weights)
        k_nearest_neighbors = loss_config.get('KNN', default_loss_config['KNN'])
        # init()
        self.criterion_losses = Losses(
            loss_types=loss_types,  # 最后输入的
            loss_weights=loss_weights,  # 最后输入的
            ignore_index=model_cfgs.IGNORE_LABEL,  # 来自yaml
            knn=k_nearest_neighbors,  # 最后输入的
            label_smoothing=label_smoothing,  # 来自yaml
        )
    '''
    基于选择的block, 输出filters, 以及重复数量, 定义子模块
    第一层与self.in_channels
    For循环从第二层到最后
    * 目前使用的ResNet一共也就两层.
    * Bottleneck
    '''
    def _make_layer(self, block, out_channels, num_block, stride=1, if_dist=False):
        layers = []
        layers.append(
            block(self.in_channels, out_channels, stride=stride, if_dist=if_dist)
        )
        self.in_channels = out_channels * block.expansion
        for _ in range(1, num_block):
            layers.append(  # 疑惑: 下面的self.in_channels , 在up1-up4之后才更新,前面的stage怎么改变的?
                block(self.in_channels, out_channels, if_dist=if_dist)
            )
        return layers

    # 网络权重的初始化, 直接附常量,而不是高斯? 权重=1 偏置=0
    def weight_initialization(self):
        for m in self.modules():
            if isinstance(m, nn.BatchNorm1d):  # 单卡, 有实例化的功能
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.SyncBatchNorm):  # 多卡
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)


    def forward(self, batch_dict, return_logit=False, return_tta=False):
        x = batch_dict['lidar']  # get_single_sample() 返回的ret, 但是lidar为SparseTensor 数据结构
        x.F = x.F[:, :self.in_feature_dim]  # input[: , :4] for minkunet, x.F 返回self.feats
        # x: SparseTensor z: PointTensor
        z = PointTensor(x.F, x.C.float())  # SparseTemspr to PointTensor
        # point feature to voxel feature
        x0 = initial_voxelize(z, self.pres, self.vres)  # 初始化+体素化, point tensor --> sparse tensor
        # 这里有个问题,在data部分,也进行了voxel特征的计算,这里又进行了voxel特征的计算,是否重复了?
        # 检查了一遍,没有重复,数据部分做的体素,只包含对体素坐标划分和特征映射,这个设计到索引和逆索引获取
        x0 = self.stem(x0)
        z0 = voxel_to_point(x0, z, nearest=False)  # x0为卷积后的特征,stem没有改变voxel的特征图尺寸,z为初始PointTensor的特征

        x1 = self.stage1(x0)  # 降采样1/2^3
        x2 = self.stage2(x1)  # 降采样1/2^3
        x3 = self.stage3(x2)  # 降采样1/2^3
        x4 = self.stage4(x3)  # 降采样1/2^3
        z1 = voxel_to_point(x4, z0)  # 在最小的特征图上, 又转了一次point特征

        x4.F = self.dropout(x4.F)  # 随机丢弃最小特征图特征(概率置为0而已),概率为yaml配置的,后续确实可以尝试下

        y1 = self.up1[0](x4)  # 上采样 2^3
        y1 = torchsparse.cat([y1, x3])  # 拼接
        y1 = self.up1[1](y1)

        y2 = self.up2[0](y1)
        y2 = torchsparse.cat([y2, x2])
        y2 = self.up2[1](y2)
        z2 = voxel_to_point(y2, z1)

        y2.F = self.dropout(y2.F)
        y3 = self.up3[0](y2)
        y3 = torchsparse.cat([y3, x1])
        y3 = self.up3[1](y3)

        y4 = self.up4[0](y3)
        y4 = torchsparse.cat([y4, x0])
        y4 = self.up4[1](y4)
        z3 = voxel_to_point(y4, z2)

        out = self.classifier(torch.cat([z1.F, z2.F, z3.F], dim=1))

        if self.training:  # 训练情况下, 见semantickitti_voxel.py ret字典
            target = batch_dict['targets'].F.long().cuda(non_blocking=True)  # labels
            # found not used
            #coords_xyz = batch_dict['lidar'].C[:, :3].float()  # coords
            #offset = batch_dict['offset']  # ret字典的基础上, 加 batch_size
            # @ 模型预测结果, @ GT标签, @ 坐标, @ offset?
            # __init__.py forward(), 这里xyz和offset 都没有参与计算
            #loss = self.criterion_losses(out, target, xyz=coords_xyz, offset=offset)
            loss = self.criterion_losses(out, target)  # @ 模型预测结果, @ GT标签

            ret_dict = {'loss': loss}
            disp_dict = {'loss': loss.item()}
            tb_dict = {'loss': loss.item()}
            return ret_dict, tb_dict, disp_dict
        else:
            invs = batch_dict['inverse_map']
            all_labels = batch_dict['targets_mapped']
            point_predict = []
            point_labels = []
            point_predict_logits = []
            for idx in range(invs.C[:, -1].max() + 1):
                cur_scene_pts = (x.C[:, -1] == idx).cpu().numpy()
                cur_inv = invs.F[invs.C[:, -1] == idx].cpu().numpy()
                cur_label = (all_labels.C[:, -1] == idx).cpu().numpy()
                if return_logit or return_tta:
                    outputs_mapped = out[cur_scene_pts][cur_inv].softmax(1)
                else:
                    outputs_mapped = out[cur_scene_pts][cur_inv].argmax(1)
                    outputs_mapped_logits = out[cur_scene_pts][cur_inv]
                targets_mapped = all_labels.F[cur_label]
                point_predict.append(outputs_mapped[:batch_dict['num_points'][idx]].cpu().numpy())
                point_labels.append(targets_mapped[:batch_dict['num_points'][idx]].cpu().numpy())
                point_predict_logits.append(outputs_mapped_logits[:batch_dict['num_points'][idx]].cpu().numpy())

            return {'point_predict': point_predict, 'point_labels': point_labels, 'name': batch_dict['name'],
                    'point_predict_logits': point_predict_logits}

    def forward_ensemble(self, batch_dict):
        return self.forward(batch_dict, ensemble=True)
