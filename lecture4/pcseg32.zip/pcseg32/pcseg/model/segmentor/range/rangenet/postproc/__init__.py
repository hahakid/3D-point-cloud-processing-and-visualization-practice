import sys
TRAIN_PATH = "../"
DEPLOY_PATH = "../../deploy"
sys.path.insert(0, TRAIN_PATH)
