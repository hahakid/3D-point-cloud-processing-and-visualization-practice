import argparse
import copy
import os
from pathlib import Path
from prettytable import PrettyTable
import numpy as np
from pcseg.data import build_dataloader
from tools.utils.train.config import cfgs, cfg_from_list, cfg_from_yaml_file
import pickle
import socket
MAX_BYTES = 65000

from show_predict import *



def parse_config():
    parser = argparse.ArgumentParser(description='PCSeg training script version 0.1')

    # == general configs ==
    parser.add_argument('--cfg_file', type=str, default='tools/cfgs/voxel/semantic_kitti/minkunet_mk18_cr10.yaml',
                        help='specify the config for training')
    parser.add_argument('--extra_tag', type=str, default='default',
                        help='extra tag for this experiment.')
    parser.add_argument('--set', dest='set_cfgs', default=None, nargs=argparse.REMAINDER,
                        help='set extra config keys if needed')
    parser.add_argument('--fix_random_seed', action='store_true', default=False,  # False, #bug4, fix the data order
                        help='whether to fix random seed.')
    # == training configs ==
    parser.add_argument('--batch_size', type=int, default=None, required=False,
                        help='batch size for model training.')
    parser.add_argument('--epochs', type=int, default=None, required=False,
                        help='number of epochs for model training.')
    parser.add_argument('--sync_bn', action='store_true', default=False,  # Fasle: single-GPU, True: multi-GPU?
                        help='whether to use sync bn.')
    parser.add_argument('--ckp', type=str, default=None,
                        help='checkpoint to start from')
    parser.add_argument('--pretrained_model', type=str, default=None,
                        help='pretrained_model')
    parser.add_argument('--amp', action='store_true', default=False,
                        help='whether to use mixture precision training.')
    parser.add_argument('--ckp_save_interval', type=int, default=1,
                        help='number of training epochs')
    parser.add_argument('--max_ckp_save_num', type=int, default=30,
                        help='max number of saved checkpoint')
    parser.add_argument('--merge_all_iters_to_one_epoch', action='store_true', default=False,
                        help='')
    # == evaluation configs ==
    parser.add_argument('--eval', action='store_true', default=False,
                        help='only perform evaluate')
    parser.add_argument('--eval_interval', type=int, default=50,
                        help='number of training epochs')
    # == device configs ==
    parser.add_argument('--workers', type=int, default=4,
                        help='number of workers for dataloader')
    parser.add_argument('--local_rank', type=int, default=0,
                        help='local rank for distributed training')
    parser.add_argument('--launcher', choices=['none', 'pytorch', 'slurm'], default='none',
                        help='')
    parser.add_argument('--tcp_port', type=int, default=18888,
                        help='tcp port for distributed training')

    args = parser.parse_args()

    cfg_from_yaml_file(args.cfg_file, cfgs)
    cfgs.TAG = Path(args.cfg_file).stem
    cfgs.EXP_GROUP_PATH = '/'.join(args.cfg_file.split('/')[2:-1])

    if args.set_cfgs is not None:
        cfg_from_list(args.set_cfgs, cfgs)

    return args, cfgs

class JK:
    def __init__(self):
        self.args = None
        self.cfgs = None
        self.dataset = None

class JK_Result:
    def __init__(self):
        self.class_names = None
        self.iou = None
        self.point_predict = None
class JK_Piece:
    def __init__(self):
        self.num = None # >=0:正常数据,-1:停止符号,-2:查询符号,返回-2:开传
        self.data = None

def client(port, data):
    # 建议端口
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    data = pickle.dumps(data)
    print("要发送的数据大小：{}".format(len(data)))
    print("正在发送信息，请耐心等待。")
    # 分片发送
    a = 0
    ans = int(len(data)/MAX_BYTES) + 1
    data_array = [JK_Piece() for _ in range(ans+1)]
    datalen = JK_Piece()
    datalen.num = -2
    datalen.data = ans
    sock.sendto(pickle.dumps(datalen), ('192.168.8.117', port))
    sock.settimeout(3)
    try:
        qdata, address = sock.recvfrom(MAX_BYTES)
        ptext = pickle.loads(qdata)
        if ptext.num != -2:
            print("服务器忙")
            return
    except socket.timeout:
        print("服务器忙或未接收到请求信息，可以发两次确定服务器接收到信息")
        return
    sock.settimeout(None)
    for i in range(0, len(data), MAX_BYTES):
        fragment = data[i:i + MAX_BYTES]
        sa = JK_Piece()
        sa.num = a
        sa.data = fragment
        data_array[sa.num] = sa
        a=a+1
    enda = JK_Piece()
    enda.num = -1
    data_array[a] = enda
    for i in range(0,len(data_array)):
        sock.sendto(pickle.dumps(data_array[i]), ('192.168.8.117', port))
        sock.settimeout(1)
        try:
            data, address = sock.recvfrom(MAX_BYTES)
            ptext = pickle.loads(data)
            if ptext != data_array[i].num:
                i = i - 1
        except socket.timeout:
            i = i-1
        sock.settimeout(None)
    print('信息已发送至 {}'.format(sock.getsockname()))
    print("等待服务器回答...")
    # 这里理论上应该和前面第一次发送信息一样，确认客户端收到长度信息，但是本次就在局域网用，比较稳定懒得改了
    data, address = sock.recvfrom(MAX_BYTES)
    ans = pickle.loads(data)
    print("接受结果需要接收{}个包".format(ans))
    data_array = [JK_Piece() for _ in range(ans)]
    # 接收分片
    fragments = []
    while True:
        data, address = sock.recvfrom(MAX_BYTES + 1000)
        ptext = pickle.loads(data)

        back = pickle.dumps(ptext.num)
        # 发送信息
        sock.sendto(back, address)

        if ptext.num == -1:
            break
        data_array[ptext.num] = ptext

    # 拼接分片
    for i in data_array:
        fragments.append(i.data)
    full_data = b''.join(fragments)
    text = pickle.loads(full_data)


    val_miou = np.nanmean(text.iou) * 100
    table_xy = PrettyTable()
    table_xy.title = 'Validation iou'
    table_xy.field_names = ["Classes", "IoU"]
    table_xy.align = 'l'
    table_xy.add_row(["All", round(val_miou, 4)])

    for i in range(len(class_names[1:])):
        table_xy.add_row([class_names[i + 1], round(text.iou[i] * 100, 4)])
    print(table_xy)
    args, cfgs = parse_config()
    if cfgs.EVALUATION.get("is_save_label", True) == True:
        print("开始保存label信息，请勿退出")
        if not os.path.exists(cfgs.EVALUATION.get("save_path")):
            os.mkdir(cfgs.EVALUATION.get("save_path"))
    if cfgs.EVALUATION.get("is_save_label", True) == True:
        batch_size = cfgs.OPTIM.BATCH_SIZE_PER_GPU
        for i, batch_dict in enumerate(jk.dataset):
            for turn in range(batch_size):
                name = i * batch_size + turn
                np.save(os.path.join(cfgs.EVALUATION.get("save_path"), str(name).zfill(6) + ".label"),
                        np.array(text.point_predict[i], dtype=np.uint32))
                os.rename(os.path.join(cfgs.EVALUATION.get("save_path"), str(name).zfill(6) + ".label.npy"),
                          os.path.join(cfgs.EVALUATION.get("save_path"), str(name).zfill(6) + ".label"))
        print("信息保存完毕，保存至"+cfgs.EVALUATION.get("save_path"))


if __name__ == '__main__':
    global jk
    jk = JK()
    args, cfgs = parse_config()
    jk.cfgs = cfgs
    jk.args = args
    data_config = copy.deepcopy(cfgs.DATA)  # 深拷贝创建一个cfg.DATA 的备份, 指向网络配置文件数据部分的字典。
    _, test_loader, _ = build_dataloader(
        data_cfgs=data_config,
        modality=cfgs.MODALITY,  # 数据模态
        batch_size=cfgs.OPTIM.BATCH_SIZE_PER_GPU,
        dist=False,
        workers=args.workers,
        logger=None,
        training=False,
    )
    class_names = test_loader.dataset.class_names
    jk.dataset = test_loader.dataset

    client(1060, jk)




    # 可视化
    # init--------------------------
    config = parase_config("R132_pridict.yaml")
    config["root_path"] = data_config.DATA_PATH
    config["predict_label_path"] = cfgs.EVALUATION.save_path

    point_list = load_point_list(config)
    label_list = load_label_list(config)
    config["learning_map"] = load_learning_map(config)
    config["color_map"] = load_color_map(config)
    pose_list = pose_init(config["root_path"])

    num_frame = len(point_list)

    continus_project_show(config, 0, num_frame, point_list, label_list, pose_list, filter=False)