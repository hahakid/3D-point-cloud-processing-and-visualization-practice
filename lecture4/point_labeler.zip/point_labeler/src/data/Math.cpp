#include "Math.h"

double Math::PI = M_PI;
