#include <mutex>
#include <atomic>
#include <thread>
#include <iostream>
#include <Eigen/Core>
#include <Eigen/Geometry>

#include <boost/format.hpp>
#include <boost/filesystem.hpp>

#include <ros/ros.h>
#include <pcl_ros/point_cloud.h>
#include <tf/transform_listener.h>

#include <nav_msgs/Odometry.h>
#include <sensor_msgs/PointCloud2.h>

#include <pcl/io/pcd_io.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>

/* 这段代码实现了一个ROS节点，它可以订阅点云和里程计数据，将数据转换为合适的格式，并将其保存到文件系统中。 */ 


// 用于保存不同类型的数据 ，  sensor_msgs::PointCloud2 类型的数据，nav_msgs::Odometry 类型的数据
template<typename T>
void save_data(const std::string& dst_directory, const T& data);

// sensor_msgs::PointCloud2 类型的数据
template<>
void save_data(const std::string& dst_directory, const sensor_msgs::PointCloud2ConstPtr& data) {
  std::stringstream dst_filename;
  dst_filename << dst_directory << "/" << data->header.stamp.sec << "_" << boost::format("%09d") % data->header.stamp.nsec << ".pcd";

  pcl::PointCloud<pcl::PointXYZI>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZI>());
  pcl::fromROSMsg(*data, *cloud);

  pcl::io::savePCDFileBinary(dst_filename.str(), *cloud);
}

// nav_msgs::Odometry 类型的数据
template<>
void save_data(const std::string& dst_directory, const nav_msgs::OdometryConstPtr& data) {
  std::stringstream dst_filename;
  dst_filename << dst_directory << "/" << data->header.stamp.sec << "_" << boost::format("%09d") % data->header.stamp.nsec << ".odom";

  const auto& pose = data->pose.pose;

  Eigen::Isometry3d odom = Eigen::Isometry3d::Identity();
  odom.translation() = Eigen::Vector3d(pose.position.x, pose.position.y, pose.position.z);
  odom.linear() = Eigen::Quaterniond(pose.orientation.w, pose.orientation.x, pose.orientation.y, pose.orientation.z).normalized().toRotationMatrix();

  std::ofstream ofs(dst_filename.str());
  ofs << odom.matrix();
  ofs.close();
}


///  这是一个线程安全的队列类，用于存储和处理数据。
template<typename T>
class SaveQueue {
public:
  SaveQueue(const std::string& dst_directory) : kill_switch(false), queue_size(0), dst_directory(dst_directory) {
    thread = std::thread([this]() { save_task(); });
  }

  size_t size() const {
    return queue_size;
  }

  void push(const T& data) {
    std::lock_guard<std::mutex> lock(mutex);
    queue.push_back(data);
    queue_size++;
  }

// SaveQueue 类的 save_task 方法在新线程中运行，不断从队列中取出数据并保存。
private:
  void save_task() {
    while(!kill_switch) {
      T data;

      {
        std::unique_lock<std::mutex> lock(mutex);

        if(queue.empty()) {
          lock.unlock();
          usleep(100);
          continue;
        }

        data = queue.front();
        queue.pop_front();
        queue_size--;
      }

      save_data(dst_directory, data);
    }
  }

private:
  std::atomic_bool kill_switch;
  std::atomic_int queue_size;

  std::mutex mutex;
  std::deque<T> queue;

  std::thread thread;

  std::string dst_directory;
};


// 这是主要的节点类，负责订阅ROS话题，处理数据，并将其保存。
class OdometrySaverNode {
public:
  OdometrySaverNode()
  : nh("~"),
    endpoint_frame(nh.param<std::string>("endpoint_frame", "base_link")),
    origin_frame(nh.param<std::string>("origin_frame", "map")),
    dst_directory(nh.param<std::string>("dst_directory", "/tmp/odometry")),
    saved_points(0),
    saved_odometry(0),
    points_save_queue(dst_directory),
    odometry_save_queue(dst_directory),
    
    // 订阅了点云和里程计数据的话题，并创建了两个 SaveQueue 实例分别用于保存点云和里程计数据。
    points_sub(nh.subscribe<sensor_msgs::PointCloud2>("/points", 128, &OdometrySaverNode::points_callback, this)),
    odometry_sub(nh.subscribe<nav_msgs::Odometry>("/odom", 128, &OdometrySaverNode::odometry_callback, this)),
    tf_listener(ros::DURATION_MAX)
  {
    boost::filesystem::create_directories(dst_directory);

    timer = nh.createWallTimer(ros::WallDuration(1.0), &OdometrySaverNode::timer_callback, this);
  }

  ~OdometrySaverNode() {}

private:
  // timer_callback 定时打印队列大小和保存的数据点数。
  void timer_callback(const ros::WallTimerEvent& e) {
    std::cout << "--- saver queues ---" << std::endl;
    std::cout << "points:" << points_save_queue.size() << "  odometry:" << odometry_save_queue.size() << std::endl;

    ROS_INFO_STREAM("queue points:" << points_save_queue.size() << "  odometry:" << odometry_save_queue.size());
    ROS_INFO_STREAM("saved points:" << saved_points << "  odometry:" << saved_odometry);
  }

  // 当接收到点云数据时，points_callback 被调用，数据被添加到点云保存队列
  void points_callback(const sensor_msgs::PointCloud2ConstPtr& points_msg) {
    saved_points++;
    points_save_queue.push(points_msg);
  }

  // 当接收到里程计数据时，odometry_callback 被调用，数据被转换并添加到里程计保存队列。
  void odometry_callback(const nav_msgs::OdometryConstPtr& odometry_msg) {
    saved_odometry++;
    Eigen::Matrix4d origin2odom = lookup_eigen(odometry_msg->header.frame_id, origin_frame);
    Eigen::Matrix4d odom2base = lookup_eigen(endpoint_frame, odometry_msg->child_frame_id);

    const auto& pose = odometry_msg->pose.pose;
    Eigen::Matrix4d odombase2odom = Eigen::Matrix4d::Identity();
    odombase2odom.block<3, 1>(0, 3) = Eigen::Vector3d(pose.position.x, pose.position.y, pose.position.z);
    odombase2odom.block<3, 3>(0, 0) = Eigen::Quaterniond(pose.orientation.w, pose.orientation.x, pose.orientation.y, pose.orientation.z).toRotationMatrix();

    Eigen::Matrix4d result = odom2base * odombase2odom * origin2odom;
    Eigen::Quaterniond quat(result.block<3, 3>(0, 0));

    nav_msgs::OdometryPtr transformed(new nav_msgs::Odometry);
    *transformed = *odometry_msg;

    auto& dst_pose = transformed->pose.pose;
    dst_pose.position.x = result(0, 3);
    dst_pose.position.y = result(1, 3);
    dst_pose.position.z = result(2, 3);

    dst_pose.orientation.w = quat.w();
    dst_pose.orientation.x = quat.x();
    dst_pose.orientation.y = quat.y();
    dst_pose.orientation.z = quat.z();

    odometry_save_queue.push(transformed);
  }

  // lookup_eigen 方法用于查找坐标系之间的变换矩阵，以便将里程计数据转换到所需的参考坐标系。
  // 作用是查询并返回两个坐标系之间的变换矩阵，使用 tf（Transform Listener）库来实现。
  /*
    
    target：目标坐标系的名称，是一个字符串。
    source：源坐标系的名称，也是一个字符串。
    stamp：时间戳，指定查询变换的时间点，默认为 ros::Time(0)，即ROS中的“现在”。

    函数返回值是一个 Eigen::Matrix4d 类型的对象，代表4x4的双精度浮点数矩阵。
  */
  Eigen::Matrix4d lookup_eigen(const std::string& target, const std::string& source, const ros::Time& stamp = ros::Time(0)) {
    // /*
      
    // tf_listener：这是一个 tf::TransformListener 类的实例，用于监听坐标变换。
    // waitForTransform：这个方法尝试获取从 source 到 target 在指定 stamp 时间的变换。如果这个变换在5秒内不可用，它将返回 false。
    // 如果 waitForTransform 返回 false，则表示在指定时间内无法获取变换，函数返回一个单位矩阵（Identity matrix），表示没有变换。

    // */
    // if(!tf_listener.waitForTransform(target, source, stamp, ros::Duration(5.0))) {
    //   return Eigen::Matrix4d::Identity();
    // }

    // // lookupTransform：这个方法查询并填充 transform 对象，它包含了从 source 到 target 在指定 stamp 时间的变换信息。
    // tf::StampedTransform transform;
    // tf_listener.lookupTransform(target, source, stamp, transform);

    // // TY 打印 target, source, 和 stamp 数据
    // ROS_INFO_STREAM("Target frame: " << target);
    // ROS_INFO_STREAM("Source frame: " << source);
    // ROS_INFO_STREAM("Time stamp: " << stamp.toSec());

    // // 这行代码创建了一个 Eigen::Matrix4d 类型的单位矩阵 matrix。
    // Eigen::Matrix4d matrix = Eigen::Matrix4d::Identity();
    // // getOpenGLMatrix：这个方法将 transform 对象中的变换数据转换为OpenGL格式的4x4矩阵，并存储在 matrix.data() 指向的内存中。matrix.data() 返回矩阵数据的指针。
    


    // transform.getOpenGLMatrix(matrix.data());

    // // ty
    // // matrix(0, 0) = -matrix(0, 0);
    // // 2行2列改为相反数，目标坐标系的y轴不由源坐标系y轴旋转180，而是保持一致
    // // matrix(1, 1) = -matrix(1, 1);
    // // // 3行3列改为相反数，目标坐标系的z轴不由源坐标系z轴旋转180，而是保持一致
    // // matrix(2, 2) = -matrix(2, 2);

    // // TY 打印最后获取到的4x4矩阵
    // ROS_INFO_STREAM("4x4 Transformation Matrix:");
    // for (int i = 0; i < matrix.rows(); ++i) {
    //     ROS_INFO_STREAM(matrix.row(i));
    // }


    // /*
    // * camera_init generally refers to the initial frame of the camera, which is the coordinate system established when the camera first started capturing data.
    // * The map frame is a global coordinate system that represents the environment in which a robot is operating.
    // * The base_link frame is the primary frame attached to the robot body. It serves as the root of the robot itself.
    // * The camera frame refers to the current position and orientation of a specific camera sensor on the robot.
    // The transformation between map and base_link gives you the global position of the robot in the environment.
    // The transformation from base_link to camera tells you where the camera is mounted on the robot.
    // The transformation from camera_init to camera can be used to track the movement of the camera since it first started capturing data.

    // */
    // return matrix;


        /*
      
    tf_listener：这是一个 tf::TransformListener 类的实例，用于监听坐标变换。
    waitForTransform：这个方法尝试获取从 source 到 target 在指定 stamp 时间的变换。如果这个变换在5秒内不可用，它将返回 false。
    如果 waitForTransform 返回 false，则表示在指定时间内无法获取变换，函数返回一个单位矩阵（Identity matrix），表示没有变换。

    */
    if(!tf_listener.waitForTransform(target, source, stamp, ros::Duration(5.0))) {
      return Eigen::Matrix4d::Identity();
    }

    // lookupTransform：这个方法查询并填充 transform 对象，它包含了从 source 到 target 在指定 stamp 时间的变换信息。
    tf::StampedTransform transform;
    tf_listener.lookupTransform(target, source, stamp, transform);



    // TY 打印 target, source, 和 stamp 数据
    ROS_INFO_STREAM("Target frame: " << target);
    ROS_INFO_STREAM("Source frame: " << source);
    ROS_INFO_STREAM("Time stamp: " << stamp.toSec());

    // 这行代码创建了一个 Eigen::Matrix4d 类型的单位矩阵 matrix。
    Eigen::Matrix4d matrix = Eigen::Matrix4d::Identity();
    
    // // 创建一个绕 x 轴旋转 90 度的旋转矩阵
    Eigen::Matrix4d rotation_x_90 = Eigen::Matrix4d::Identity();
    rotation_x_90(1, 1) = 0;
    rotation_x_90(1, 2) = -1;
    rotation_x_90(2, 1) = 1;
    rotation_x_90(2, 2) = 0;

    // 将 rotation_x_90 与 matrix 相乘，添加旋转效果
    matrix = rotation_x_90 * matrix;

    // getOpenGLMatrix：这个方法将 transform 对象中的变换数据转换为OpenGL格式的4x4矩阵，并存储在 matrix.data() 指向的内存中。matrix.data() 返回矩阵数据的指针。
    transform.getOpenGLMatrix(matrix.data());



    // ty
    // matrix(0, 0) = -matrix(0, 0);
    // 2行2列改为相反数，目标坐标系的y轴不由源坐标系y轴旋转180，而是保持一致
    // matrix(1, 1) = -matrix(1, 1);
    // // 3行3列改为相反数，目标坐标系的z轴不由源坐标系z轴旋转180，而是保持一致
    // matrix(2, 2) = -matrix(2, 2);

    // TY 打印最后获取到的4x4矩阵
    ROS_INFO_STREAM("4x4 Transformation Matrix:");
    for (int i = 0; i < matrix.rows(); ++i) {
        ROS_INFO_STREAM(matrix.row(i));
    }



    return matrix;
  }

private:
  ros::NodeHandle nh;
  ros::WallTimer timer;

  std::string endpoint_frame;
  std::string origin_frame;

  int saved_points;
  int saved_odometry;

  std::string dst_directory;
  SaveQueue<sensor_msgs::PointCloud2ConstPtr> points_save_queue;
  SaveQueue<nav_msgs::OdometryConstPtr> odometry_save_queue;

  ros::Subscriber points_sub;
  ros::Subscriber odometry_sub;

  tf::TransformListener tf_listener;
};


// 初始化ROS节点并创建 OdometrySaverNode 实例，然后进入ROS事件循环
int main(int argc, char** argv) {
  ros::init(argc, argv, "odometry_saver");

  OdometrySaverNode node;

  ros::spin();

  return 0;
}
